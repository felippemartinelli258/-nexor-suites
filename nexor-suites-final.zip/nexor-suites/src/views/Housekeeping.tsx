import { useDemo, setHousekeeping } from '../data/store'
import { categoryOf, guestOfRoom, housekeepingTasks, kpis, roomByNum } from '../data/selectors'
import { fmtDayMonth } from '../lib/dates'
import type { Task, TaskStatus } from '../types'
import { Flow, Lane, LaneEmpty } from './ops/shared'

type Action = { to: TaskStatus; label: string; primary?: boolean }

// Ações disponíveis em cada etapa da governança.
const ACTIONS: Partial<Record<TaskStatus, Action[]>> = {
  pendente: [{ to: 'andamento', label: 'Iniciar limpeza', primary: true }],
  andamento: [{ to: 'limpo', label: 'Marcar como limpo', primary: true }],
  limpo: [
    { to: 'concluida', label: 'Liberar quarto', primary: true },
    { to: 'inspecao', label: 'Enviar para inspeção' },
  ],
  inspecao: [
    { to: 'concluida', label: 'Aprovar e liberar', primary: true },
    { to: 'andamento', label: 'Reprovar: voltar à limpeza' },
  ],
}

const LANES: { st: TaskStatus; title: string; hint: string; tone: 'a' | 'w' | 'g' | 'e' | 'i' }[] = [
  { st: 'pendente', title: 'Limpeza pendente', hint: 'Check-out feito, aguardando equipe', tone: 'e' },
  { st: 'andamento', title: 'Em limpeza', hint: 'Equipe no quarto', tone: 'w' },
  { st: 'limpo', title: 'Limpo', hint: 'Pronto para liberar', tone: 'a' },
  { st: 'inspecao', title: 'Inspeção', hint: 'Conferência antes de liberar', tone: 'i' },
]

export function Housekeeping() {
  const s = useDemo()
  const k = kpis(s)
  const tasks = housekeepingTasks(s)
  const run = (t: Task, to: TaskStatus) => setHousekeeping(t.id, to)

  return (
    <>
      <h1>Governança</h1>
      <p className="sub">Limpeza e liberação dos quartos após o check-out · {k.free} livres agora</p>
      <Flow steps={['Checkout', 'Limpeza', 'Limpo', 'Livre']} />
      <p className="flow-note">Inspeção é opcional entre Limpo e Livre.</p>
      <div className="lanes">
        {LANES.map(l => {
          const items = tasks.filter(t => t.status === l.st)
          return (
            <Lane key={l.st} title={l.title} hint={l.hint} count={items.length} tone={l.tone}>
              {items.length === 0 && <LaneEmpty>Nenhum quarto nesta etapa.</LaneEmpty>}
              {items.map(t => {
                const room = roomByNum(s, t.room)
                return (
                  <article key={t.id} className="hk" data-task={t.id} data-room={t.room} data-status={t.status}>
                    <div className="hk-top">
                      <b>Quarto {t.room}</b>
                      <span className="hk-cat">{room ? categoryOf(room).name : ''}</span>
                    </div>
                    <small>Pós check-out · {guestOfRoom(s, t.room)} · desde {fmtDayMonth(t.since)}</small>
                    <div className="hk-acts">
                      {(ACTIONS[t.status] ?? []).map(a => (
                        <button key={a.to} type="button" className={a.primary ? 'btn sm' : 'btn ghost sm'} onClick={() => run(t, a.to)}>
                          {a.label}
                        </button>
                      ))}
                    </div>
                  </article>
                )
              })}
            </Lane>
          )
        })}
      </div>
    </>
  )
}
