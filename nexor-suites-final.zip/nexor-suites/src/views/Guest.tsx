import { useEffect, useState } from 'react'
import type { ReactNode } from 'react'
import { LogoIcon } from '../components/Brand'
import { TENANT } from '../data/seed'
import { requestTitle, submitGuestRequest, useDemo } from '../data/store'
import { categoryOf, guestById, roomByNum, stayOf } from '../data/selectors'
import { DEMO_TODAY, daysBetween, fmtDayMonth, fmtFull, nights } from '../lib/dates'
import type { GuestRequest, RequestKind } from '../types'
import { Icon, REQUEST_STATUS } from './guest/shared'
import type { IconName } from './guest/shared'

type View = 'home' | 'stay' | 'wifi' | 'breakfast' | 'pool' | 'services' | 'request' | 'rules' | 'guide' | 'review' | 'checkout'
const VIEWS: View[] = ['home', 'stay', 'wifi', 'breakfast', 'pool', 'services', 'request', 'rules', 'guide', 'review', 'checkout']

const readHash = (): View => {
  const h = window.location.hash.replace('#', '') as View
  return VIEWS.includes(h) ? h : 'home'
}

function useView(): [View, (v: View) => void] {
  const [view, setView] = useState<View>(readHash)
  useEffect(() => {
    const on = () => {
      setView(readHash())
      window.scrollTo(0, 0)
    }
    window.addEventListener('hashchange', on)
    window.addEventListener('popstate', on)
    return () => {
      window.removeEventListener('hashchange', on)
      window.removeEventListener('popstate', on)
    }
  }, [])
  const go = (v: View) => {
    if (v === 'home') {
      window.history.pushState(null, '', window.location.pathname)
      setView('home')
      window.scrollTo(0, 0)
    } else window.location.hash = v
  }
  return [view, go]
}

const TILES: { view: View; icon: IconName; name: string; sub: string }[] = [
  { view: 'stay', icon: 'stay', name: 'Minha estadia', sub: 'Datas e detalhes' },
  { view: 'wifi', icon: 'wifi', name: 'Wi-Fi', sub: 'Conecte-se' },
  { view: 'breakfast', icon: 'coffee', name: 'Café da manhã', sub: '07h às 10h30' },
  { view: 'pool', icon: 'pool', name: 'Piscina', sub: '08h às 20h' },
  { view: 'services', icon: 'bell', name: 'Serviços', sub: 'O que oferecemos' },
  { view: 'request', icon: 'ask', name: 'Solicitar algo', sub: 'Peça pelo celular' },
  { view: 'rules', icon: 'rules', name: 'Regras', sub: 'Boa convivência' },
  { view: 'guide', icon: 'pin', name: 'Guia local', sub: 'Guriri e região' },
  { view: 'review', icon: 'star', name: 'Avaliar estadia', sub: 'Conte como foi' },
  { view: 'checkout', icon: 'logout', name: 'Checkout', sub: 'Saída tranquila' },
]

const TITLES: Record<View, string> = {
  home: '', stay: 'Minha estadia', wifi: 'Wi-Fi', breakfast: 'Café da manhã', pool: 'Piscina', services: 'Serviços',
  request: 'Solicitar algo', rules: 'Regras da casa', guide: 'Guia local', review: 'Avaliar estadia', checkout: 'Checkout',
}

export function GuestExperience({ slug, room: num }: { slug: string; room: string }) {
  const s = useDemo()
  const [view, go] = useView()
  const room = roomByNum(s, num)
  const valid = slug === TENANT.slug && !!room
  const stay = valid ? stayOf(s, num) : undefined
  const guest = stay ? guestById(s, stay.guestId) : undefined
  const first = guest?.name.split(' ')[0]
  useEffect(() => {
    const prev = document.title
    document.title = valid ? `${TENANT.name} · Quarto ${num}` : 'Nexor Suítes'
    return () => {
      document.title = prev
    }
  }, [valid, num])

  if (!valid || !room) {
    return (
      <div className="gst">
        <div className="g-aurora" />
        <div className="g-wrap g-center">
          <LogoIcon size={56} />
          <h1>Quarto não encontrado</h1>
          <p className="g-mute">Confira o QR Code do seu quarto ou fale com a recepção.</p>
        </div>
      </div>
    )
  }
  const mine = s.requests.filter(q => q.room === num).slice().reverse()
  const cat = categoryOf(room)

  return (
    <div className="gst" data-view={view}>
      <div className="g-aurora" />
      <div className="g-wrap">
        <header className="g-top">
          {view === 'home' ? (
            <div className="g-brand">
              <LogoIcon size={34} />
              <div><b>{TENANT.name}</b><small>{TENANT.loc}</small></div>
            </div>
          ) : (
            <button type="button" className="g-back" onClick={() => go('home')} aria-label="Voltar ao início">
              <Icon name="back" size={20} /> <span>{TITLES[view]}</span>
            </button>
          )}
          <span className="g-chip" data-testid="g-room">Quarto {num}</span>
        </header>

        {view === 'home' && (
          <main className="g-main g-home" key="home">
            <section className="g-left">
              <p className="g-eyebrow">Concierge digital</p>
              <h1 className="g-hello" data-testid="g-hello">{first ? `Olá, ${first} 👋` : 'Olá 👋'}</h1>
              <p className="g-lead">
                {stay ? `Bem-vinda à ${TENANT.name}. Tudo que você precisa durante sua estadia está aqui.` : `Este quarto não tem hospedagem ativa no momento.`}
              </p>
              {stay && guest && (
                <div className="g-stay" data-testid="g-stay">
                  <div className="g-stay-top">
                    <div>
                      <small>Sua estadia</small>
                      <b className="g-dates">{fmtDayMonth(stay.checkIn)} <i>→</i> {fmtDayMonth(stay.checkOut)}</b>
                    </div>
                    <div className="g-room-big">
                      <small>{cat.name}</small>
                      <b>Quarto {num}</b>
                    </div>
                  </div>
                  <div className="g-prog" aria-hidden="true">
                    <i style={{ width: `${(Math.min(Math.max(daysBetween(stay.checkIn, DEMO_TODAY) + 1, 1), nights(stay.checkIn, stay.checkOut)) / nights(stay.checkIn, stay.checkOut)) * 100}%` }} />
                  </div>
                  <div className="g-stay-foot">
                    <span>Dia {Math.min(Math.max(daysBetween(stay.checkIn, DEMO_TODAY) + 1, 1), nights(stay.checkIn, stay.checkOut))} de {nights(stay.checkIn, stay.checkOut)}</span>
                    <span>Check-out {fmtFull(stay.checkOut)} às {stay.checkOutTime}</span>
                  </div>
                  <div className="g-guestline">{guest.name} · {fmtFull(stay.checkIn)} → {fmtFull(stay.checkOut)}</div>
                </div>
              )}
              {stay && (
                <button type="button" className="g-cta" onClick={() => go('request')} data-testid="g-cta">
                  <Icon name="ask" size={20} /> Solicitar algo
                </button>
              )}
              {mine.length > 0 && (
                <div className="g-mine">
                  <h2>Seus pedidos</h2>
                  <RequestList items={mine.slice(0, 3)} />
                </div>
              )}
            </section>
            <section className="g-right" aria-label="Acessos rápidos">
              <div className="g-tiles">
                {TILES.map((t, i) => (
                  <button key={t.view} type="button" className="g-tile" style={{ animationDelay: `${i * 40}ms` }} onClick={() => go(t.view)} data-tile={t.view}>
                    <span className="g-ico"><Icon name={t.icon} /></span>
                    <b>{t.name}</b>
                    <small>{t.sub}</small>
                  </button>
                ))}
              </div>
            </section>
          </main>
        )}

        {view !== 'home' && (
          <main className="g-main g-page" key={view}>
            {view === 'stay' && <StayView num={num} cat={cat.name} stayData={stay} guestName={guest?.name} />}
            {view === 'wifi' && <WifiView num={num} />}
            {view === 'breakfast' && <BreakfastView />}
            {view === 'pool' && <PoolView go={go} />}
            {view === 'services' && <ServicesView go={go} />}
            {view === 'request' && <RequestView num={num} active={!!stay} mine={mine} go={go} />}
            {view === 'rules' && <RulesView />}
            {view === 'guide' && <GuideView />}
            {view === 'review' && <ReviewView first={first} />}
            {view === 'checkout' && <CheckoutView num={num} stayData={stay} mine={mine} />}
          </main>
        )}
        <footer className="g-foot">Experiência digital por <b>Nexor Suítes</b></footer>
      </div>
    </div>
  )
}

function RequestList({ items }: { items: GuestRequest[] }) {
  return (
    <div className="g-list" data-testid="g-requests">
      {items.map(q => (
        <div className="g-li" key={q.id} data-request={q.id}>
          <div><b>{q.title}</b><small>{q.origin === 'hospede' ? 'Enviado agora pelo app' : 'Registrado pela equipe'}</small></div>
          <span className={`chip ${REQUEST_STATUS[q.status].chip}`}>{REQUEST_STATUS[q.status].label}</span>
        </div>
      ))}
    </div>
  )
}

function Panel({ title, children }: { title?: string; children: ReactNode }) {
  return (
    <div className="g-panel">
      {title && <h2>{title}</h2>}
      {children}
    </div>
  )
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="g-kv">
      <span>{label}</span>
      <b>{value}</b>
    </div>
  )
}

type StayData = ReturnType<typeof stayOf>

function StayView({ num, cat, stayData, guestName }: { num: string; cat: string; stayData: StayData; guestName?: string }) {
  if (!stayData) return <Panel><p className="g-mute">Sem hospedagem ativa neste quarto.</p></Panel>
  const n = nights(stayData.checkIn, stayData.checkOut)
  return (
    <>
      <Panel>
        <Row label="Hóspede" value={guestName ?? '—'} />
        <Row label="Quarto" value={`${num} · ${cat}`} />
        <Row label="Entrada" value={`${fmtFull(stayData.checkIn)} às ${stayData.checkInTime}`} />
        <Row label="Saída" value={`${fmtFull(stayData.checkOut)} às ${stayData.checkOutTime}`} />
        <Row label="Duração" value={`${n} ${n === 1 ? 'noite' : 'noites'}`} />
      </Panel>
      <p className="g-note">Precisa estender a estadia? Fale com a recepção — teremos prazer em ajudar.</p>
    </>
  )
}

function WifiView({ num }: { num: string }) {
  const net = `MarAzul${num}`, pass = `guriri${num}`
  const [copied, setCopied] = useState('')
  const copy = async (what: string, text: string) => {
    try {
      await navigator.clipboard.writeText(text)
      setCopied(what)
      setTimeout(() => setCopied(''), 1800)
    } catch {
      setCopied('')
    }
  }
  return (
    <>
      <Panel>
        <div className="g-wifi">
          <span className="g-ico lg"><Icon name="wifi" size={28} /></span>
          <div><small>Rede</small><b>{net}</b></div>
          <button type="button" className="g-mini" onClick={() => copy('net', net)}>{copied === 'net' ? <><Icon name="check" size={16} /> Copiado</> : <><Icon name="copy" size={16} /> Copiar</>}</button>
        </div>
        <div className="g-wifi">
          <span className="g-ico lg"><Icon name="rules" size={28} /></span>
          <div><small>Senha</small><b>{pass}</b></div>
          <button type="button" className="g-mini" onClick={() => copy('pass', pass)}>{copied === 'pass' ? <><Icon name="check" size={16} /> Copiado</> : <><Icon name="copy" size={16} /> Copiar</>}</button>
        </div>
      </Panel>
      <p className="g-note">Sinal disponível no quarto, na piscina e no salão de café da manhã.</p>
    </>
  )
}

function BreakfastView() {
  return (
    <>
      <Panel>
        <Row label="Horário" value="07h às 10h30" />
        <Row label="Local" value="Salão Maré, térreo" />
        <Row label="Incluso" value="Sim, na diária" />
      </Panel>
      <Panel title="No buffet">
        <ul className="g-ul"><li>Pães, bolos e tapioca na hora</li><li>Frutas frescas da estação e sucos naturais</li><li>Ovos, queijos, frios e café coado</li><li>Opções sem glúten e sem lactose sob consulta</li></ul>
      </Panel>
    </>
  )
}

function PoolView({ go }: { go: (v: View) => void }) {
  return (
    <>
      <Panel>
        <Row label="Horário" value="08h às 20h" />
        <Row label="Profundidade" value="1,20 m (adulto e infantil)" />
        <Row label="Toalhas" value="Disponíveis na área da piscina" />
      </Panel>
      <Panel title="Antes de mergulhar">
        <ul className="g-ul"><li>Tome uma ducha rápida antes de entrar</li><li>Evite copos de vidro na área molhada</li><li>Crianças sempre acompanhadas por um adulto</li></ul>
      </Panel>
      <button type="button" className="g-cta" onClick={() => go('request')}><Icon name="towel" size={20} /> Pedir toalhas extras</button>
    </>
  )
}

function ServicesView({ go }: { go: (v: View) => void }) {
  const items: [IconName, string, string][] = [
    ['clean', 'Limpeza do quarto', 'Diária, sob demanda'],
    ['towel', 'Enxoval extra', 'Toalhas e travesseiros'],
    ['coffee', 'Café no quarto', 'Sob consulta na recepção'],
    ['pin', 'Passeios e transfer', 'Indicação da recepção'],
    ['wrench', 'Manutenção', 'Resolvemos rápido'],
  ]
  return (
    <>
      <Panel>
        {items.map(([ic, name, sub]) => (
          <div className="g-svc" key={name}>
            <span className="g-ico"><Icon name={ic} /></span>
            <div><b>{name}</b><small>{sub}</small></div>
          </div>
        ))}
      </Panel>
      <button type="button" className="g-cta" onClick={() => go('request')}><Icon name="ask" size={20} /> Solicitar algo</button>
    </>
  )
}

function RulesView() {
  const rules = ['Silêncio das 22h às 8h', 'Não é permitido fumar dentro dos quartos', 'Visitas apenas na área de convivência, até as 21h', 'Animais de estimação: consulte a recepção', 'Cuide das chaves e das toalhas da casa', 'Descarte o lixo nas lixeiras indicadas']
  return (
    <Panel>
      <ul className="g-ul checks">{rules.map(r => <li key={r}>{r}</li>)}</ul>
    </Panel>
  )
}

function GuideView() {
  const places: [string, string][] = [
    ['Praia de Guriri', 'Orla tranquila, ótima para caminhar ao nascer do sol.'],
    ['Restaurantes de frutos do mar', 'Moquecas capixabas e pratos do dia à beira-mar.'],
    ['Passeios de barco', 'Roteiros pela costa e pelo rio, com saída pela manhã.'],
    ['Pôr do sol na orla', 'Melhor horário: cerca de 17h30 — leve um casaco leve.'],
  ]
  return (
    <>
      <Panel>
        {places.map(([n, d]) => (
          <div className="g-svc" key={n}>
            <span className="g-ico"><Icon name="pin" /></span>
            <div><b>{n}</b><small>{d}</small></div>
          </div>
        ))}
      </Panel>
      <p className="g-note">Sugestões da recepção. Peça um mapa impresso quando quiser.</p>
    </>
  )
}

function ReviewView({ first }: { first?: string }) {
  const [stars, setStars] = useState(0)
  const [text, setText] = useState('')
  const [sent, setSent] = useState(false)
  if (sent)
    return (
      <Panel>
        <div className="g-done"><span className="g-okc"><Icon name="check" size={34} /></span><h2>Obrigado{first ? `, ${first}` : ''}!</h2><p className="g-mute">Sua avaliação ajuda a Pousada Mar Azul a cuidar ainda melhor de cada hóspede.</p></div>
      </Panel>
    )
  return (
    <Panel title="Como está sendo sua estadia?">
      <div className="g-stars" role="radiogroup" aria-label="Nota">
        {[1, 2, 3, 4, 5].map(n => (
          <button key={n} type="button" role="radio" aria-checked={stars === n} aria-label={`${n} estrelas`} className={n <= stars ? 'on' : ''} onClick={() => setStars(n)}>
            <Icon name="star" size={34} fill={n <= stars} />
          </button>
        ))}
      </div>
      <textarea className="g-ta" rows={3} placeholder="Quer contar mais? (opcional)" value={text} onChange={e => setText(e.target.value)} />
      <button type="button" className="g-cta" disabled={stars === 0} onClick={() => setSent(true)}>Enviar avaliação</button>
    </Panel>
  )
}

function CheckoutView({ num, stayData, mine }: { num: string; stayData: StayData; mine: GuestRequest[] }) {
  const [err, setErr] = useState('')
  if (!stayData) return <Panel><p className="g-mute">Sem hospedagem ativa neste quarto.</p></Panel>
  const asked = mine.some(q => q.title === 'Check-out solicitado' && q.status !== 'concluida')
  const send = () => {
    const r = submitGuestRequest(num, 'outro', 1, '', 'Check-out solicitado')
    setErr(r.ok ? '' : r.message)
  }
  return (
    <>
      <Panel>
        <Row label="Saída prevista" value={`${fmtFull(stayData.checkOut)} às ${stayData.checkOutTime}`} />
        <Row label="Quarto" value={num} />
      </Panel>
      <Panel title="Antes de sair">
        <ul className="g-ul checks"><li>Confira seus pertences e carregadores</li><li>Deixe a chave na recepção</li><li>Avise a equipe quando estiver saindo</li></ul>
      </Panel>
      {asked ? (
        <div className="g-done soft"><span className="g-okc sm"><Icon name="check" size={22} /></span><p>Recepção avisada. Obrigado pela estadia!</p></div>
      ) : (
        <button type="button" className="g-cta" onClick={send}><Icon name="logout" size={20} /> Avisar a recepção que estou saindo</button>
      )}
      {err && <p className="g-err" role="alert">{err}</p>}
    </>
  )
}

const OPTIONS: { kind: RequestKind; icon: IconName; name: string; sub: string; qty?: boolean; note?: 'required' | 'optional' }[] = [
  { kind: 'toalhas', icon: 'towel', name: 'Toalhas extras', sub: 'Banho ou piscina', qty: true },
  { kind: 'limpeza', icon: 'clean', name: 'Limpeza', sub: 'Arrumar o quarto' },
  { kind: 'manutencao', icon: 'wrench', name: 'Manutenção', sub: 'Algo não funciona', note: 'optional' },
  { kind: 'agua', icon: 'drop', name: 'Água', sub: 'Garrafas geladas', qty: true },
  { kind: 'travesseiros', icon: 'pillow', name: 'Travesseiros', sub: 'Mais conforto', qty: true },
  { kind: 'outro', icon: 'chat', name: 'Outro pedido', sub: 'Conte o que precisa', note: 'required' },
]

function RequestView({ num, active, mine, go }: { num: string; active: boolean; mine: GuestRequest[]; go: (v: View) => void }) {
  const [kind, setKind] = useState<RequestKind | null>(null)
  const [qty, setQty] = useState(1)
  const [note, setNote] = useState('')
  const [err, setErr] = useState('')
  const [sentId, setSentId] = useState<string | null>(null)
  const opt = OPTIONS.find(o => o.kind === kind)
  const sent = sentId ? mine.find(q => q.id === sentId) : undefined

  if (!active) return <Panel><p className="g-mute">Este quarto não tem hospedagem ativa para receber pedidos.</p></Panel>

  if (sent)
    return (
      <>
        <div className="g-done" data-testid="g-sent">
          <span className="g-okc"><Icon name="check" size={34} /></span>
          <h2>Pedido enviado</h2>
          <p className="g-sent-title" data-testid="g-sent-title">{sent.title}</p>
          <span className={`chip ${REQUEST_STATUS[sent.status].chip}`}>{REQUEST_STATUS[sent.status].label}</span>
          <p className="g-mute">A equipe já foi avisada e vai até o quarto {num}.</p>
        </div>
        <div className="g-actions">
          <button type="button" className="g-cta" onClick={() => go('home')}>Voltar ao início</button>
          <button type="button" className="g-ghost" onClick={() => { setSentId(null); setKind(null); setQty(1); setNote('') }}>Fazer outro pedido</button>
        </div>
        <div className="g-mine"><h2>Seus pedidos</h2><RequestList items={mine} /></div>
      </>
    )

  const submit = () => {
    if (!opt) return
    const r = submitGuestRequest(num, opt.kind, qty, note)
    if (r.ok && r.id) {
      setErr('')
      setSentId(r.id)
      window.scrollTo(0, 0)
    } else setErr(r.message)
  }
  const preview = opt ? requestTitle(opt.kind, qty, note.trim()) : ''

  return (
    <>
      <p className="g-lead sm">O que você precisa? Escolha uma opção e a equipe cuida do resto.</p>
      <div className="g-opts" role="radiogroup" aria-label="Tipo de pedido">
        {OPTIONS.map(o => (
          <button key={o.kind} type="button" role="radio" aria-checked={kind === o.kind} className={`g-opt ${kind === o.kind ? 'on' : ''}`} data-opt={o.kind}
            onClick={() => { setKind(o.kind); setQty(1); setNote(''); setErr('') }}>
            <span className="g-ico"><Icon name={o.icon} /></span>
            <b>{o.name}</b>
            <small>{o.sub}</small>
          </button>
        ))}
      </div>
      {opt && (
        <div className="g-form" key={opt.kind}>
          {opt.qty && (
            <div className="g-qty">
              <span>Quantidade</span>
              <div className="g-step">
                <button type="button" aria-label="Diminuir" onClick={() => setQty(q => Math.max(1, q - 1))} disabled={qty <= 1}><Icon name="minus" size={18} /></button>
                <output aria-live="polite" data-testid="g-qty">{qty}</output>
                <button type="button" aria-label="Aumentar" onClick={() => setQty(q => Math.min(10, q + 1))} disabled={qty >= 10}><Icon name="plus" size={18} /></button>
              </div>
            </div>
          )}
          {opt.note && (
            <textarea className="g-ta" rows={3} maxLength={240} aria-label={opt.note === 'required' ? 'Descreva seu pedido' : 'Descreva o problema'}
              placeholder={opt.note === 'required' ? 'Descreva o que você precisa' : 'Descreva o problema (opcional)'} value={note} onChange={e => setNote(e.target.value)} />
          )}
          <div className="g-sum"><small>Você vai enviar</small><b data-testid="g-preview">{preview || 'Descreva seu pedido'}</b></div>
          {err && <p className="g-err" role="alert">{err}</p>}
          <button type="button" className="g-cta" onClick={submit} data-testid="g-send"><Icon name="check" size={20} /> Enviar pedido</button>
        </div>
      )}
      {mine.length > 0 && !opt && <div className="g-mine"><h2>Seus pedidos</h2><RequestList items={mine} /></div>}
    </>
  )
}
