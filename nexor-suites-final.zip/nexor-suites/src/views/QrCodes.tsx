import { useEffect, useState } from 'react'
import { Link } from '../router'
import { CATEGORIES, DEMO_ROOM, TENANT } from '../data/seed'
import { useDemo } from '../data/store'
import { ROOM_LABEL, categoryOf } from '../data/selectors'
import { QrImage, downloadQr } from '../components/QrImage'
import { guestPath, guestUrl } from '../lib/urls'
import type { CategoryId, Room } from '../types'

const CHIP = { o: 'a', v: 'g', l: 'w', m: 'e' } as const

function useDownload() {
  const [err, setErr] = useState('')
  const run = (room: string) => {
    setErr('')
    downloadQr(guestUrl(room), `Quarto ${room} · ${TENANT.name}`, `qr-quarto-${room}.png`).catch(e => setErr(e instanceof Error ? e.message : 'Não foi possível baixar.'))
  }
  return { err, run }
}

function QrDialog({ room, onClose, onDownload }: { room: Room; onClose: () => void; onDownload: (n: string) => void }) {
  useEffect(() => {
    const on = (e: KeyboardEvent) => e.key === 'Escape' && onClose()
    window.addEventListener('keydown', on)
    return () => window.removeEventListener('keydown', on)
  }, [onClose])
  return (
    <div className="ov" onClick={onClose}>
      <div className="dlg qrdlg" role="dialog" aria-label={`QR do quarto ${room.num}`} onClick={e => e.stopPropagation()}>
        <div className="dh">
          <div>
            <h2>Quarto {room.num}</h2>
            <small>{categoryOf(room).name}</small>
          </div>
          <span className={`chip ${CHIP[room.status]}`}>{ROOM_LABEL[room.status]}</span>
        </div>
        <QrImage value={guestUrl(room.num)} label={`QR Code do quarto ${room.num}`} className="big" />
        <code className="url" data-testid="qr-dialog-url">{guestUrl(room.num)}</code>
        <div className="acts">
          <button type="button" className="btn" onClick={() => onDownload(room.num)}>Baixar QR</button>
          <Link to={guestPath(room.num)} className="btn ghost" style={{ textAlign: 'center', textDecoration: 'none' }}>Abrir experiência</Link>
          <button type="button" className="btn ghost close" onClick={onClose}>Fechar</button>
        </div>
      </div>
    </div>
  )
}

export function QrCodes() {
  const s = useDemo()
  const [cat, setCat] = useState<CategoryId | 'todos'>('todos')
  const [view, setView] = useState<string | null>(null)
  const dl = useDownload()
  const featured = s.rooms.find(r => r.num === DEMO_ROOM)
  const list = s.rooms.filter(r => cat === 'todos' || r.category === cat)
  const viewing = s.rooms.find(r => r.num === view)
  return (
    <>
      <div className="head">
        <div>
          <h1>QR Codes</h1>
          <p className="sub">Um QR real para cada quarto — o hóspede escaneia e abre a própria experiência, sem instalar nada</p>
        </div>
      </div>
      {featured && (
        <div className="card qrfeat" data-testid="qr-featured">
          <QrImage value={guestUrl(featured.num)} label={`QR Code do quarto ${featured.num}`} className="feat" />
          <div className="qrinfo">
            <h3>Quarto em destaque</h3>
            <h2>Quarto {featured.num}</h2>
            <div className="meta">
              <span>{categoryOf(featured).name}</span>
              <span className={`chip ${CHIP[featured.status]}`}>{ROOM_LABEL[featured.status]}</span>
            </div>
            <label>Rota</label>
            <code>{guestPath(featured.num)}</code>
            <label>URL do QR (origem atual)</label>
            <code className="url" data-testid="qr-featured-url">{guestUrl(featured.num)}</code>
            <div className="btns">
              <button type="button" className="btn" onClick={() => setView(featured.num)}>Visualizar QR</button>
              <button type="button" className="btn ghost" onClick={() => dl.run(featured.num)}>Baixar QR</button>
              <Link to={guestPath(featured.num)} className="btn ghost" style={{ textDecoration: 'none' }}>Abrir experiência</Link>
            </div>
            {dl.err && <div className="toast" style={{ background: 'rgba(248,113,113,.15)', color: 'var(--er)' }}>{dl.err}</div>}
          </div>
        </div>
      )}
      <div className="tabs" style={{ marginTop: 20 }}>
        <button type="button" className={cat === 'todos' ? 'on' : ''} onClick={() => setCat('todos')}>Todos {s.rooms.length}</button>
        {CATEGORIES.map(c => (
          <button key={c.id} type="button" className={cat === c.id ? 'on' : ''} onClick={() => setCat(c.id)}>
            {c.name} {s.rooms.filter(r => r.category === c.id).length}
          </button>
        ))}
      </div>
      <div className="qrgrid">
        {list.map(r => (
          <div className="card qrcard" key={r.num} data-qr-room={r.num}>
            <QrImage value={guestUrl(r.num)} label={`QR Code do quarto ${r.num}`} className="sm" />
            <div className="qrc">
              <div className="qrt">
                <b>Quarto {r.num}</b>
                <span className={`chip ${CHIP[r.status]}`}>{ROOM_LABEL[r.status]}</span>
              </div>
              <small>{categoryOf(r).name}</small>
              <code>{guestPath(r.num)}</code>
              <div className="btns">
                <button type="button" className="btn ghost sm" onClick={() => setView(r.num)}>Visualizar</button>
                <button type="button" className="btn ghost sm" onClick={() => dl.run(r.num)}>Baixar</button>
              </div>
            </div>
          </div>
        ))}
      </div>
      {viewing && <QrDialog room={viewing} onClose={() => setView(null)} onDownload={dl.run} />}
    </>
  )
}
