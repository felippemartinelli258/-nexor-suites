import type { ReactNode } from 'react'

/** Coluna de status (kanban leve): cabeçalho com contagem e lista de cartões. */
export function Lane({ title, hint, count, tone, children }: { title: string; hint: string; count: number; tone: 'a' | 'w' | 'g' | 'e' | 'i'; children: ReactNode }) {
  return (
    <section className={`lane tone-${tone}`}>
      <header className="lane-h">
        <div>
          <b>{title}</b>
          <small>{hint}</small>
        </div>
        <span className="lane-count">{count}</span>
      </header>
      <div className="lane-b">{children}</div>
    </section>
  )
}

export function LaneEmpty({ children }: { children: ReactNode }) {
  return <p className="lane-empty">{children}</p>
}

/** Fluxo visual de etapas, ex.: Checkout → Limpeza → Limpo → Livre. */
export function Flow({ steps, current }: { steps: string[]; current?: number }) {
  return (
    <ol className="flow" aria-label="Fluxo">
      {steps.map((s, i) => (
        <li key={s} className={current === i ? 'on' : current !== undefined && i < current ? 'done' : ''}>
          <span>{i + 1}</span>
          {s}
        </li>
      ))}
    </ol>
  )
}
