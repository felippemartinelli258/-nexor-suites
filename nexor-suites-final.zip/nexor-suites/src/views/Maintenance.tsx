import { useState } from 'react'
import { useDemo, openMaintenance, setMaintenance } from '../data/store'
import { maintenanceTasks, roomByNum, guestOfRoom } from '../data/selectors'
import { DEMO_TODAY, daysBetween, fmtDayMonth } from '../lib/dates'
import type { Task } from '../types'
import { Flow, Lane, LaneEmpty } from './ops/shared'

type MtStatus = 'pendente' | 'andamento' | 'concluida'
const SUGESTOES = ['Ar-condicionado', 'Chuveiro', 'Vazamento', 'Fechadura', 'Iluminação', 'TV']

const ACTIONS: Record<MtStatus, { to: MtStatus; label: string; primary?: boolean }[]> = {
  pendente: [{ to: 'andamento', label: 'Iniciar atendimento', primary: true }],
  andamento: [
    { to: 'concluida', label: 'Marcar como resolvido', primary: true },
    { to: 'pendente', label: 'Voltar para aberto' },
  ],
  concluida: [{ to: 'pendente', label: 'Reabrir' }],
}

const LANES: { st: MtStatus; title: string; hint: string; tone: 'a' | 'w' | 'g' }[] = [
  { st: 'pendente', title: 'Aberto', hint: 'Aguardando atendimento', tone: 'a' },
  { st: 'andamento', title: 'Em atendimento', hint: 'Técnico no quarto', tone: 'w' },
  { st: 'concluida', title: 'Resolvido', hint: 'Concluídos', tone: 'g' },
]

export function Maintenance() {
  const s = useDemo()
  const [room, setRoom] = useState('')
  const [title, setTitle] = useState('')
  const [formOpen, setFormOpen] = useState(false)
  const [msg, setMsg] = useState('')
  const [err, setErr] = useState('')
  const tasks = maintenanceTasks(s)
  const active = tasks.filter(t => t.status !== 'concluida').length

  const run = (t: Task, to: MtStatus) => setMsg(setMaintenance(t.id, to).message)

  const submit = () => {
    const r = openMaintenance(room, title)
    if (r.ok) {
      setErr('')
      setMsg(r.message)
      setTitle('')
      setRoom('')
      setFormOpen(false)
    } else setErr(r.message)
  }

  return (
    <>
      <div className="head">
        <div>
          <h1>Manutenção</h1>
          <p className="sub">{active} {active === 1 ? 'ordem ativa' : 'ordens ativas'} · acompanhe cada atendimento até resolver</p>
        </div>
        <button type="button" className="btn sm" onClick={() => { setFormOpen(o => !o); setErr('') }} aria-expanded={formOpen}>
          {formOpen ? 'Fechar' : 'Nova ordem'}
        </button>
      </div>
      <Flow steps={['Aberto', 'Em atendimento', 'Resolvido']} />

      {formOpen && (
        <div className="card mt-form">
          <h3>Abrir ordem de manutenção</h3>
          <div className="fgrid">
            <label className="fld">
              <span>Quarto</span>
              <select value={room} onChange={e => setRoom(e.target.value)} data-testid="mt-room">
                <option value="">Escolha o quarto</option>
                {s.rooms.map(r => (
                  <option key={r.num} value={r.num}>{r.num}{r.status === 'o' ? ' · ocupado' : ''}</option>
                ))}
              </select>
            </label>
            <label className="fld">
              <span>Problema</span>
              <input value={title} maxLength={120} placeholder="Ex.: Ar-condicionado com ruído" onChange={e => setTitle(e.target.value)} data-testid="mt-title" />
            </label>
          </div>
          <div className="chips">
            {SUGESTOES.map(x => (
              <button key={x} type="button" className="chip-btn" onClick={() => setTitle(x)}>{x}</button>
            ))}
          </div>
          {err && <p className="err" role="alert">{err}</p>}
          <button type="button" className="btn" onClick={submit} data-testid="mt-submit">Abrir ordem</button>
        </div>
      )}

      {msg && <div className="toast" role="status" data-testid="mt-msg">{msg}</div>}

      <div className="lanes">
        {LANES.map(l => {
          const items = tasks.filter(t => t.status === l.st).slice().reverse()
          return (
            <Lane key={l.st} title={l.title} hint={l.hint} count={items.length} tone={l.tone}>
              {items.length === 0 && <LaneEmpty>Nenhuma ordem nesta etapa.</LaneEmpty>}
              {items.map(t => {
                const r = roomByNum(s, t.room)
                const days = daysBetween(t.since, DEMO_TODAY)
                return (
                  <article key={t.id} className="mt" data-task={t.id} data-room={t.room} data-status={t.status}>
                    <div className="hk-top">
                      <b>Quarto {t.room}</b>
                      <span className={`chip ${r ? { o: 'a', v: 'g', l: 'w', m: 'e' }[r.status] : ''}`}>{r ? { o: 'Ocupado', v: 'Livre', l: 'Limpeza', m: 'Manutenção' }[r.status] : ''}</span>
                    </div>
                    <div className="mt-title">{t.title}</div>
                    <div className="mt-origin" data-testid="mt-origin">
                      <span>Origem</span>
                      <b>{t.origin ?? 'Registrada pela equipe'}</b>
                      {t.guest && <small>{t.guest} · Quarto {t.room}</small>}
                    </div>
                    <small>
                      {t.status === 'concluida' ? 'Resolvido' : `Aberto desde ${fmtDayMonth(t.since)}`}
                      {t.status !== 'concluida' && ` · ${days} ${days === 1 ? 'dia' : 'dias'}`}
                      {r?.status === 'o' ? ` · hóspede ${guestOfRoom(s, t.room)}` : ''}
                    </small>
                    <div className="hk-acts">
                      {ACTIONS[t.status as MtStatus].map(a => (
                        <button key={a.to} type="button" className={a.primary ? 'btn sm' : 'btn ghost sm'} onClick={() => run(t, a.to)}>
                          {a.label}
                        </button>
                      ))}
                    </div>
                  </article>
                )
              })}
            </Lane>
          )
        })}
      </div>
    </>
  )
}
