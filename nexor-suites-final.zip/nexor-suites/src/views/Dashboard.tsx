import { Link } from '../router'
import { InstallButton } from '../components/InstallButton'
import { RoomMap, Legend } from '../components/RoomMap'
import { useDemo, restoreDemo, setRequestStatus, requestToMaintenance } from '../data/store'
import { REVENUE_NOTE, TENANT } from '../data/seed'
import { alerts, guestOfRoom, isOpen, kpis, occupancyByCategory, operations, recentActivity, timeline } from '../data/selectors'
import { DEMO_TODAY, brl, fmtLong } from '../lib/dates'

/** 1 pendente · 2 pendentes */
const qty = (n: number, one: string, many: string) => `${n} ${n === 1 ? one : many}`

const greeting = () => {
  const h = new Date().getHours()
  return h < 12 ? 'Bom dia' : h < 18 ? 'Boa tarde' : 'Boa noite'
}

export function Dashboard() {
  const s = useDemo()
  const k = kpis(s)
  const op = operations(s)
  const open = s.requests.filter(isOpen)
  // Fila: urgentes primeiro, depois em andamento, depois pendentes; dentro de cada grupo, por ordem de chegada.
  const rank = (q: { urgent: boolean; status: string }) => (q.urgent ? 0 : q.status === 'andamento' ? 1 : 2)
  const queue = open.slice().sort((a, b) => rank(a) - rank(b))
  const activity = recentActivity(s, 8)
  return (
    <>
      <div className="head">
        <div>
          <h1>{greeting()}, {TENANT.manager.split(' ')[0]}.</h1>
          <p className="sub">Veja o que está acontecendo na sua hospedagem · {fmtLong(DEMO_TODAY)}</p>
        </div>
        <div className="head-actions">
          <InstallButton />
          <button type="button" className="btn ghost sm" onClick={() => restoreDemo()}>Restaurar demonstração</button>
        </div>
      </div>
      <p className="pulse" data-testid="pulse">
        <span className="pulse-dot" aria-hidden="true" />
        <em className="pulse-now">Agora</em>
        <b>{k.occupied} de {k.total} quartos ocupados</b>
        <span>· {op.maintenance.inProgress > 0 ? `${op.maintenance.inProgress} manutenção em atendimento` : 'nenhuma manutenção em atendimento'}</span>
        <span>· {qty(op.checkins.total - op.checkins.done, 'chegada a fazer', 'chegadas a fazer')}</span>
        <span>· {qty(op.checkouts.total - op.checkouts.done, 'saída a fazer', 'saídas a fazer')}</span>
        <span>· {op.requests.urgent > 0 ? `${op.requests.urgent} ${op.requests.urgent === 1 ? 'urgente' : 'urgentes'}` : 'nenhuma urgência'}</span>
      </p>
      <div className="hero">
        <div className="card occ">
          <div className="ring" style={{ background: `conic-gradient(var(--ac) ${k.occupancyPct}%, var(--s2) 0)` }}><i>{k.occupancyPct}%</i></div>
          <div>
            <h3 style={{ margin: '0 0 6px' }}>Ocupação atual</h3>
            <b style={{ fontSize: 18 }}>{k.occupied} de {k.total} quartos</b>
            <div className="sub" style={{ margin: '4px 0 0', fontSize: 13 }}>{k.free} livres · {k.cleaning} em limpeza · {k.maintenance} em manutenção</div>
          </div>
        </div>
        <div className="card kp">
          <Link to="/reservas" className="k kl"><span>Check-ins hoje</span><b>{op.checkins.total}</b><em>{op.checkins.done} já realizados</em></Link>
          <Link to="/reservas" className="k kl"><span>Check-outs hoje</span><b>{op.checkouts.total}</b><em>{op.checkouts.total - op.checkouts.done} pendentes</em></Link>
          <div className="k"><span>Receita do mês</span><b>{brl(k.revenueMonth)}</b><em>{REVENUE_NOTE}</em></div>
          <Link to="/solicitacoes" className="k kl"><span>Solicitações abertas</span><b>{k.openRequests}</b><em style={{ color: 'var(--wa)' }}>{k.urgentRequests} urgentes</em></Link>
        </div>
      </div>

      <div className="ops" aria-label="Operação agora">
        <Link to="/solicitacoes" className="op" data-op="solicitacoes">
          <span>Solicitações</span>
          <b>{op.requests.open}</b>
          <small>{qty(op.requests.pending, 'pendente', 'pendentes')} · {op.requests.inProgress} em andamento</small>
        </Link>
        <Link to="/governanca" className="op" data-op="governanca">
          <span>Limpeza</span>
          <b>{op.cleaning.open}</b>
          <small>{qty(op.cleaning.pending, 'pendente', 'pendentes')} · {op.cleaning.inProgress} em limpeza · {op.cleaning.clean} limpo{op.cleaning.clean === 1 ? '' : 's'}</small>
        </Link>
        <Link to="/manutencao" className="op" data-op="manutencao">
          <span>Manutenção</span>
          <b>{op.maintenance.active}</b>
          <small>{qty(op.maintenance.open, 'aberta', 'abertas')} · {op.maintenance.inProgress} em atendimento</small>
        </Link>
        <Link to="/reservas" className="op" data-op="checkins">
          <span>Check-ins</span>
          <b>{op.checkins.done}<i>/{op.checkins.total}</i></b>
          <small>{qty(op.checkins.total - op.checkins.done, 'chegada pendente', 'chegadas pendentes')}</small>
        </Link>
        <Link to="/reservas" className="op" data-op="checkouts">
          <span>Check-outs</span>
          <b>{op.checkouts.done}<i>/{op.checkouts.total}</i></b>
          <small>{qty(op.checkouts.total - op.checkouts.done, 'saída pendente', 'saídas pendentes')}</small>
        </Link>
      </div>

      <div className="grid">
        <div className="card">
          <h3>Mapa dos quartos</h3>
          <RoomMap />
          <Legend />
        </div>
        <div className="card">
          <h3>Timeline operacional</h3>
          <ul className="tl">
            {timeline(s).map((t, i) => (
              <li key={i} style={{ opacity: t.done ? 0.55 : 1 }}>
                <time>{t.time}</time>
                <div>{t.done ? '✓ ' : ''}{t.title}<small>{t.detail}</small></div>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="grid grid3">
        <div className="card">
          <h3>Solicitações de hóspedes</h3>
          {open.length === 0 && <p className="sub" style={{ margin: 0 }}>Nenhuma solicitação aberta.</p>}
          <div className="qlist">
          {queue.map(q => (
            <div className="row dq" key={q.id}>
              <div className="t"><b>{q.title}</b><small>Quarto {q.room} · {guestOfRoom(s, q.room)}</small></div>
              <span className={`chip ${q.urgent ? 'e' : q.status === 'andamento' ? 'w' : 'a'}`}>{q.urgent ? 'Urgente' : q.status === 'andamento' ? 'Em andamento' : 'Pendente'}</span>
              {q.status === 'nova' && q.kind !== 'manutencao' && (
                <button type="button" className="btn ghost sm" onClick={() => setRequestStatus(q.id, 'andamento')}>Iniciar</button>
              )}
              {q.kind === 'manutencao' && q.status === 'nova' ? (
                <button type="button" className="btn ghost sm" onClick={() => requestToMaintenance(q.id)}>Ordem</button>
              ) : (
                <button type="button" className="btn ghost sm" onClick={() => setRequestStatus(q.id, 'concluida')}>Concluir</button>
              )}
            </div>
          ))}
          </div>
          {open.length > 0 && <Link to="/solicitacoes" className="more">Abrir Solicitações ({open.length} abertas) →</Link>}
        </div>
        <div className="card">
          <h3>Alertas</h3>
          {alerts(s).map(a => (
            <div className="row" key={a.text}>
              <span className={`chip ${a.tone}`}>●</span>
              <div className="t"><small style={{ color: 'var(--tx)' }}>{a.text}</small></div>
            </div>
          ))}
        </div>
        <div className="card">
          <h3>Ocupação por categoria</h3>
          {occupancyByCategory(s).map(c => (
            <div key={c.name} style={{ marginBottom: 12 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13 }}>
                <span>{c.name}</span>
                <span style={{ color: 'var(--mu)' }}>{c.occupied}/{c.total} · {c.pct}%</span>
              </div>
              <div className="pb"><i style={{ width: `${c.pct}%` }} /></div>
            </div>
          ))}
        </div>
      </div>

      <div className="card act">
        <h3>Atividades recentes</h3>
        {activity.length === 0 && <p className="sub" style={{ margin: 0 }}>Nenhuma atividade registrada.</p>}
        <ul className="act-list">
          {activity.map(a => (
            <li key={a.id} data-activity={a.id}>
              <time>{a.time}</time>
              <span>{a.text}</span>
            </li>
          ))}
        </ul>
      </div>
    </>
  )
}
