import { Link } from '../router'
import { QrImage } from '../components/QrImage'
import { DEMO_ROOM } from '../data/seed'
import { useDemo } from '../data/store'
import { guestName, stayOf } from '../data/selectors'
import { fmtFull } from '../lib/dates'
import { guestPath, guestUrl } from '../lib/urls'
import { REQUEST_STATUS } from './guest/shared'

// Painel da gestão para a experiência do hóspede: abre a rota pública real e acompanha os pedidos do quarto.
export function GuestPreview() {
  const s = useDemo()
  const stay = stayOf(s, DEMO_ROOM)
  const mine = s.requests.filter(q => q.room === DEMO_ROOM).slice().reverse()
  return (
    <>
      <h1>Experiência do hóspede</h1>
      <p className="sub">O que o hóspede abre ao escanear o QR do quarto {DEMO_ROOM} — uma página pública real, em tela cheia</p>
      <div className="guest">
        <div className="card">
          <h3>Hóspede atual</h3>
          {stay ? (
            <div className="box">
              <b>{guestName(s, stay.guestId)}</b>
              <small>Quarto {DEMO_ROOM}</small>
              <small>{fmtFull(stay.checkIn)} → {fmtFull(stay.checkOut)}</small>
            </div>
          ) : (
            <p className="sub" style={{ margin: 0 }}>Este quarto não tem hospedagem ativa no momento.</p>
          )}
          <p style={{ color: 'var(--mu)', fontSize: 13, margin: '14px 0 6px' }}>Rota pública</p>
          <code style={{ color: 'var(--ac)', fontSize: 13, wordBreak: 'break-all' }} data-testid="guest-route">{guestPath(DEMO_ROOM)}</code>
          <div className="btns" style={{ marginTop: 16 }}>
            <Link to={guestPath(DEMO_ROOM)} className="btn" style={{ textDecoration: 'none' }} data-testid="open-guest">Abrir experiência do hóspede</Link>
            <Link to="/qr-codes" className="btn ghost" style={{ textDecoration: 'none' }}>Ver QR Codes</Link>
          </div>
          <h3 style={{ marginTop: 24 }}>Pedidos do quarto {DEMO_ROOM}</h3>
          {mine.length === 0 && <p className="sub" style={{ margin: 0 }}>Nenhum pedido ainda.</p>}
          {mine.map(q => (
            <div className="row" key={q.id} data-request={q.id}>
              <div className="t"><b>{q.title}</b><small>{q.origin === 'hospede' ? 'Pelo app do hóspede' : 'Registrado pela equipe'}</small></div>
              <span className={`chip ${REQUEST_STATUS[q.status].chip}`}>{REQUEST_STATUS[q.status].label}</span>
            </div>
          ))}
        </div>
        <div className="card" style={{ textAlign: 'center' }}>
          <h3>QR do quarto {DEMO_ROOM}</h3>
          <QrImage value={guestUrl(DEMO_ROOM)} label={`QR Code do quarto ${DEMO_ROOM}`} className="med" />
          <code style={{ color: 'var(--mu)', fontSize: 11, wordBreak: 'break-all' }}>{guestUrl(DEMO_ROOM)}</code>
        </div>
      </div>
    </>
  )
}
