import { useState } from 'react'
import { useDemo, setRequestStatus, requestToMaintenance } from '../data/store'
import { REQ_LABEL, guestOfRoom } from '../data/selectors'
import type { GuestRequest } from '../types'
import { Link } from '../router'

type Filter = 'todas' | GuestRequest['status']
const FILTERS: { id: Filter; label: string }[] = [
  { id: 'todas', label: 'Todas' },
  { id: 'nova', label: 'Pendentes' },
  { id: 'andamento', label: 'Em andamento' },
  { id: 'concluida', label: 'Concluídas' },
]
const STEPS: GuestRequest['status'][] = ['nova', 'andamento', 'concluida']
const CHIP = { nova: 'a', andamento: 'w', concluida: 'g' } as const

export function Requests() {
  const s = useDemo()
  const [filter, setFilter] = useState<Filter>('todas')
  const [msg, setMsg] = useState('')
  const run = (r: { message: string }) => setMsg(r.message)

  // Mais recentes primeiro; urgentes abertos no topo; concluídas por último.
  const rank = (q: GuestRequest) => (q.status === 'concluida' ? 2 : q.urgent ? 0 : 1)
  const list = s.requests
    .filter(q => filter === 'todas' || q.status === filter)
    .slice()
    .reverse()
    .sort((a, b) => rank(a) - rank(b))

  return (
    <>
      <h1>Solicitações</h1>
      <p className="sub">Pedidos dos hóspedes · atualize o status e o hóspede acompanha no celular</p>
      <div className="tabs" role="tablist">
        {FILTERS.map(f => (
          <button key={f.id} role="tab" aria-selected={filter === f.id} className={filter === f.id ? 'on' : ''} onClick={() => setFilter(f.id)}>
            {f.label} {f.id === 'todas' ? s.requests.length : s.requests.filter(q => q.status === f.id).length}
          </button>
        ))}
      </div>
      {msg && <div className="toast" role="status" data-testid="rq-msg">{msg}</div>}
      {list.length === 0 && <div className="card"><p className="sub" style={{ margin: 0 }}>Nenhuma solicitação nesta lista.</p></div>}
      <div className="rq-grid">
        {list.map(q => {
          const done = q.status === 'concluida'
          return (
            <article key={q.id} className={`rq ${q.urgent && !done ? 'urg' : ''} ${done ? 'done' : ''}`} data-request={q.id} data-status={q.status}>
              <div className="rq-top">
                <span className="rq-room">Quarto {q.room}</span>
                <span className="rq-badges">
                  {q.urgent && !done && <span className="chip e">Urgente</span>}
                  <span className={`chip ${CHIP[q.status]}`} data-testid="rq-status">{REQ_LABEL[q.status]}</span>
                </span>
              </div>
              <div className="rq-title">{q.title}</div>
              <div className="rq-meta">
                {guestOfRoom(s, q.room)} · {q.origin === 'hospede' ? 'Pelo app do hóspede' : 'Registrado pela equipe'}
              </div>
              {q.note && <p className="rq-note">“{q.note}”</p>}
              <div className="seg" role="group" aria-label={`Status de ${q.title}`}>
                {STEPS.map(st => (
                  <button key={st} type="button" aria-pressed={q.status === st} className={q.status === st ? 'on' : ''}
                    data-set={st} onClick={() => run(setRequestStatus(q.id, st))}>
                    {REQ_LABEL[st]}
                  </button>
                ))}
              </div>
              {q.kind === 'manutencao' && !done && (
                <button type="button" className="btn ghost sm" onClick={() => run(requestToMaintenance(q.id))}>
                  Abrir ordem de manutenção
                </button>
              )}
            </article>
          )
        })}
      </div>
      <p className="rq-foot">Para ver o pedido no celular do hóspede, abra a <Link to="/hospede">experiência do hóspede</Link>.</p>
    </>
  )
}
