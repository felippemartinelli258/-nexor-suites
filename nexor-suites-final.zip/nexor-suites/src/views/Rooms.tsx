import { useState } from 'react'
import { CATEGORIES } from '../data/seed'
import { useDemo } from '../data/store'
import type { CategoryId } from '../types'
import { RoomMap, Legend } from '../components/RoomMap'

export function Rooms() {
  const s = useDemo()
  const [cat, setCat] = useState<CategoryId | 'todos'>('todos')
  return (
    <>
      <h1>Quartos</h1>
      <p className="sub">{s.rooms.length} acomodações · toque em um quarto para ver detalhes e alterar o estado</p>
      <div className="tabs">
        <button className={cat === 'todos' ? 'on' : ''} onClick={() => setCat('todos')}>Todos</button>
        {CATEGORIES.map(c => (
          <button key={c.id} className={c.id === cat ? 'on' : ''} onClick={() => setCat(c.id)}>{c.name}</button>
        ))}
      </div>
      <div className="card">
        <RoomMap category={cat} />
        <Legend />
      </div>
    </>
  )
}
