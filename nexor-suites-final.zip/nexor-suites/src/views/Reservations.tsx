import { useState } from 'react'
import { useDemo, checkIn, checkOut } from '../data/store'
import { RES_LABEL, categoryOf, guestName, reservationTotal, roomByNum } from '../data/selectors'
import { DEMO_TODAY, brl, fmtShort, nights } from '../lib/dates'
import type { Reservation } from '../types'

const initials = (n: string) => n.split(' ').map(x => x[0]).slice(0, 2).join('')
const CHIP = { hospedado: 'a', confirmada: 'g', pre: 'w', finalizada: '' } as const

const TABS: { id: string; label: string; test: (r: Reservation) => boolean }[] = [
  { id: 'hoje', label: 'Hoje', test: r => (r.checkIn === DEMO_TODAY && r.status !== 'pre') || (r.checkOut === DEMO_TODAY && r.status !== 'confirmada' && r.status !== 'pre') },
  { id: 'hosp', label: 'Hospedados', test: r => r.status === 'hospedado' },
  { id: 'prox', label: 'Próximas', test: r => r.checkIn > DEMO_TODAY },
  { id: 'enc', label: 'Encerradas', test: r => r.status === 'finalizada' },
  { id: 'todas', label: 'Todas', test: () => true },
]

export function Reservations() {
  const s = useDemo()
  const [tab, setTab] = useState('hoje')
  const [msg, setMsg] = useState('')
  const t = TABS.find(x => x.id === tab)!
  const list = s.reservations.filter(t.test).sort((a, b) => a.checkIn.localeCompare(b.checkIn) || a.room.localeCompare(b.room))
  return (
    <>
      <h1>Reservas</h1>
      <p className="sub">{s.reservations.length} reservas · chegadas, estadias em andamento e próximas</p>
      <div className="tabs">
        {TABS.map(x => (
          <button key={x.id} className={x.id === tab ? 'on' : ''} onClick={() => setTab(x.id)}>
            {x.label} {s.reservations.filter(x.test).length}
          </button>
        ))}
      </div>
      {msg && <div className="toast" role="status" data-testid="res-msg">{msg}</div>}
      <div className="card">
        {list.length === 0 && <p className="sub" style={{ margin: 0 }}>Nenhuma reserva nesta lista.</p>}
        {list.map(r => {
          const room = roomByNum(s, r.room)
          const name = guestName(s, r.guestId)
          const canIn = r.status === 'confirmada' && r.checkIn <= DEMO_TODAY && room?.status === 'v'
          return (
            <div className="row" key={r.id} data-res={r.id}>
              <div className="av">{initials(name)}</div>
              <div className="t">
                <b>{name}</b>
                <div className="res-meta">
                  <span className="res-room">Quarto {r.room}</span>
                  {room && <span>{categoryOf(room).name}</span>}
                  <span>{fmtShort(r.checkIn)} → {fmtShort(r.checkOut)}</span>
                  <span>{nights(r.checkIn, r.checkOut)} {nights(r.checkIn, r.checkOut) === 1 ? 'noite' : 'noites'}</span>
                  <span className="res-val">{brl(reservationTotal(s, r))}</span>
                </div>
              </div>
              {canIn && <button className="btn sm" onClick={() => setMsg(checkIn(r.id).message)} data-testid="do-checkin">Fazer check-in</button>}
              {r.status === 'hospedado' && <button className="btn ghost sm" onClick={() => setMsg(checkOut(r.id).message)} data-testid="do-checkout">Fazer check-out</button>}
              <span className={`chip ${CHIP[r.status]}`}>{RES_LABEL[r.status]}</span>
            </div>
          )
        })}
      </div>
    </>
  )
}
