import type { ComponentType } from 'react'
import { Link, usePath } from './router'
import { Shell } from './components/Shell'
import { Dashboard } from './views/Dashboard'
import { Rooms } from './views/Rooms'
import { Reservations } from './views/Reservations'
import { GuestPreview } from './views/GuestPreview'
import { QrCodes } from './views/QrCodes'
import { Requests } from './views/Requests'
import { Housekeeping } from './views/Housekeeping'
import { Maintenance } from './views/Maintenance'
import { GuestExperience } from './views/Guest'
import { parseGuestPath } from './lib/urls'

const ROUTES: Record<string, ComponentType> = {
  '/': Dashboard,
  '/solicitacoes': Requests,
  '/governanca': Housekeeping,
  '/manutencao': Maintenance,
  '/quartos': Rooms,
  '/reservas': Reservations,
  '/hospede': GuestPreview,
  '/qr-codes': QrCodes,
}

export default function App() {
  const path = usePath()
  const guest = parseGuestPath(path)
  if (guest) return <GuestExperience slug={guest.slug} room={guest.room} />
  const View = ROUTES[path]
  return (
    <Shell>
      {View ? (
        <View />
      ) : (
        <div className="nf">
          <h1>Página não encontrada</h1>
          <Link to="/" className="btn">Voltar ao Dashboard</Link>
        </div>
      )}
    </Shell>
  )
}
