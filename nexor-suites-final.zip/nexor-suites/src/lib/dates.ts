// Utilitários de data (ISO yyyy-mm-dd, sem fuso horário).
export const DEMO_TODAY = '2026-10-10'

const MONTHS = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro']
const MONTHS_SHORT = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez']
const WEEKDAYS = ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sáb']

function parse(iso: string): Date {
  const [y, m, d] = iso.split('-').map(Number)
  return new Date(Date.UTC(y, m - 1, d))
}

export function nights(checkIn: string, checkOut: string): number {
  return Math.round((parse(checkOut).getTime() - parse(checkIn).getTime()) / 86400000)
}

export function daysBetween(from: string, to: string): number {
  return nights(from, to)
}

export function addDays(iso: string, n: number): string {
  const d = parse(iso)
  d.setUTCDate(d.getUTCDate() + n)
  return d.toISOString().slice(0, 10)
}

export const monthOf = (iso: string) => iso.slice(0, 7)

/** 2026-10-10 → 10/10/2026 */
export function fmtFull(iso: string): string {
  const [y, m, d] = iso.split('-')
  return `${d}/${m}/${y}`
}

/** 2026-10-10 → 10/10 */
export function fmtShort(iso: string): string {
  const [, m, d] = iso.split('-')
  return `${d}/${m}`
}

/** 2026-10-10 → sáb, 10 de outubro */
export function fmtLong(iso: string): string {
  const d = parse(iso)
  return `${WEEKDAYS[d.getUTCDay()]}, ${d.getUTCDate()} de ${MONTHS[d.getUTCMonth()]}`
}

export const brl = (n: number) => 'R$ ' + n.toLocaleString('pt-BR')

/** 2026-10-10 → 10 out */
export function fmtDayMonth(iso: string): string {
  const d = parse(iso)
  return `${d.getUTCDate()} ${MONTHS_SHORT[d.getUTCMonth()]}`
}
