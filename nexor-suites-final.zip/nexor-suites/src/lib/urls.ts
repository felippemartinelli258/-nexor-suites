import { TENANT } from '../data/seed'

/** Rota pública do hóspede: /guest/mar-azul/room/204 */
export const guestPath = (room: string) => `/guest/${TENANT.slug}/room/${room}`

/** URL completa usando a ORIGEM ATUAL (localhost em desenvolvimento, domínio da Vercel em produção). Nada de URL fixa. */
export const guestUrl = (room: string) => `${typeof window === 'undefined' ? '' : window.location.origin}${guestPath(room)}`

export function parseGuestPath(path: string): { slug: string; room: string } | null {
  const m = /^\/guest\/([^/]+)\/room\/([^/]+)$/.exec(path)
  return m ? { slug: decodeURIComponent(m[1]), room: decodeURIComponent(m[2]) } : null
}
