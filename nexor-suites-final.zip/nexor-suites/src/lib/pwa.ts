// PWA: registro do service worker e instalação opcional (sem popup).
import { useSyncExternalStore } from 'react'

type InstallEvent = Event & { prompt: () => Promise<{ outcome: 'accepted' | 'dismissed' }> }

let deferred: InstallEvent | null = null
let installed = false
const listeners = new Set<() => void>()
const notify = () => listeners.forEach(l => l())

/** Registra o service worker. Ignorado no servidor de desenvolvimento do Vite (evita cache de código antigo). */
export function registerServiceWorker() {
  if (typeof window === 'undefined' || !('serviceWorker' in navigator)) return
  if ((import.meta as ImportMeta & { env?: { DEV?: boolean } }).env?.DEV) return
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch(() => {
      /* sem PWA: a aplicação segue funcionando normalmente */
    })
  })
}

if (typeof window !== 'undefined') {
  window.addEventListener('beforeinstallprompt', e => {
    e.preventDefault() // guardamos o evento e só mostramos o botão discreto
    deferred = e as InstallEvent
    notify()
  })
  window.addEventListener('appinstalled', () => {
    deferred = null
    installed = true
    notify()
  })
}

export const isStandalone = () =>
  typeof window !== 'undefined' && (window.matchMedia('(display-mode: standalone)').matches || (navigator as Navigator & { standalone?: boolean }).standalone === true)

const subscribe = (l: () => void) => {
  listeners.add(l)
  return () => listeners.delete(l)
}

/** Estado de instalação: canInstall = o navegador oferece instalação e o app ainda não está instalado. */
export function useInstall() {
  const canInstall = useSyncExternalStore(subscribe, () => !!deferred && !installed && !isStandalone(), () => false)
  const install = async (): Promise<'accepted' | 'dismissed' | 'unavailable'> => {
    if (!deferred) return 'unavailable'
    const { outcome } = await deferred.prompt()
    deferred = null
    notify()
    return outcome
  }
  return { canInstall, install }
}
