// Gerador de QR Code próprio (sem dependências, sem internet).
// Modo byte (UTF-8), correção de erro nível M, versões 1–10 (até 213 bytes) — de sobra para URLs de quarto.
// Retorna a matriz de módulos (true = escuro). Validado com leitor de QR real nos testes.

// [ecc por bloco, blocos grupo 1, dados por bloco g1, blocos grupo 2, dados por bloco g2] — nível M
const EC_M: Record<number, [number, number, number, number, number]> = {
  1: [10, 1, 16, 0, 0],
  2: [16, 1, 28, 0, 0],
  3: [26, 1, 44, 0, 0],
  4: [18, 2, 32, 0, 0],
  5: [24, 2, 43, 0, 0],
  6: [16, 4, 27, 0, 0],
  7: [18, 4, 31, 0, 0],
  8: [22, 2, 38, 2, 39],
  9: [22, 3, 36, 2, 37],
  10: [26, 4, 43, 1, 44],
}
const ALIGN: Record<number, number[]> = {
  1: [], 2: [6, 18], 3: [6, 22], 4: [6, 26], 5: [6, 30], 6: [6, 34], 7: [6, 22, 38], 8: [6, 24, 42], 9: [6, 26, 46], 10: [6, 28, 50],
}

const dataCapacity = (v: number) => {
  const [, b1, d1, b2, d2] = EC_M[v]
  return b1 * d1 + b2 * d2
}

function gfMul(x: number, y: number): number {
  let z = 0
  for (let i = 7; i >= 0; i--) {
    z = (z << 1) ^ ((z >>> 7) * 0x11d)
    z ^= ((y >>> i) & 1) * x
  }
  return z & 0xff
}

function rsDivisor(degree: number): number[] {
  const r = new Array<number>(degree).fill(0)
  r[degree - 1] = 1
  let root = 1
  for (let i = 0; i < degree; i++) {
    for (let j = 0; j < degree; j++) {
      r[j] = gfMul(r[j], root)
      if (j + 1 < degree) r[j] ^= r[j + 1]
    }
    root = gfMul(root, 2)
  }
  return r
}

function rsRemainder(data: number[], divisor: number[]): number[] {
  const r = new Array<number>(divisor.length).fill(0)
  for (const b of data) {
    const f = b ^ (r.shift() as number)
    r.push(0)
    divisor.forEach((c, i) => {
      r[i] ^= gfMul(c, f)
    })
  }
  return r
}

const utf8 = (text: string): number[] => Array.from(new TextEncoder().encode(text))

export function qrMatrix(text: string): boolean[][] {
  const bytes = utf8(text)
  let version = 0
  for (let v = 1; v <= 10; v++) {
    const countBits = v < 10 ? 8 : 16
    if (4 + countBits + bytes.length * 8 <= dataCapacity(v) * 8) {
      version = v
      break
    }
  }
  if (!version) throw new Error('Texto longo demais para o QR (máx. ~213 bytes).')

  // 1) bits de dados
  const bits: number[] = []
  const push = (val: number, len: number) => {
    for (let i = len - 1; i >= 0; i--) bits.push((val >>> i) & 1)
  }
  push(0b0100, 4)
  push(bytes.length, version < 10 ? 8 : 16)
  bytes.forEach(b => push(b, 8))
  const cap = dataCapacity(version) * 8
  push(0, Math.min(4, cap - bits.length))
  while (bits.length % 8) bits.push(0)
  const data: number[] = []
  for (let i = 0; i < bits.length; i += 8) data.push(parseInt(bits.slice(i, i + 8).join(''), 2))
  for (let pad = 0xec; data.length < dataCapacity(version); pad ^= 0xec ^ 0x11) data.push(pad)

  // 2) blocos + Reed-Solomon + intercalação
  const [eccLen, b1, d1, b2, d2] = EC_M[version]
  const div = rsDivisor(eccLen)
  const blocks: { data: number[]; ecc: number[] }[] = []
  let k = 0
  for (let i = 0; i < b1 + b2; i++) {
    const len = i < b1 ? d1 : d2
    const d = data.slice(k, k + len)
    k += len
    blocks.push({ data: d, ecc: rsRemainder(d, div) })
  }
  const codewords: number[] = []
  for (let i = 0; i < Math.max(d1, d2); i++) blocks.forEach(b => i < b.data.length && codewords.push(b.data[i]))
  for (let i = 0; i < eccLen; i++) blocks.forEach(b => codewords.push(b.ecc[i]))

  // 3) matriz
  const size = version * 4 + 17
  const mod: boolean[][] = Array.from({ length: size }, () => new Array<boolean>(size).fill(false))
  const fn: boolean[][] = Array.from({ length: size }, () => new Array<boolean>(size).fill(false))
  const set = (x: number, y: number, dark: boolean) => {
    mod[y][x] = dark
    fn[y][x] = true
  }
  for (let i = 0; i < size; i++) {
    set(6, i, i % 2 === 0)
    set(i, 6, i % 2 === 0)
  }
  const finder = (cx: number, cy: number) => {
    for (let dy = -4; dy <= 4; dy++)
      for (let dx = -4; dx <= 4; dx++) {
        const d = Math.max(Math.abs(dx), Math.abs(dy))
        const x = cx + dx, y = cy + dy
        if (x >= 0 && x < size && y >= 0 && y < size) set(x, y, d !== 2 && d !== 4)
      }
  }
  finder(3, 3)
  finder(size - 4, 3)
  finder(3, size - 4)
  const al = ALIGN[version]
  for (let i = 0; i < al.length; i++)
    for (let j = 0; j < al.length; j++) {
      if ((i === 0 && j === 0) || (i === 0 && j === al.length - 1) || (i === al.length - 1 && j === 0)) continue
      for (let dy = -2; dy <= 2; dy++)
        for (let dx = -2; dx <= 2; dx++) set(al[i] + dx, al[j] + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1)
    }

  const formatBits = (mask: number) => {
    const d = (0 << 3) | mask // nível M = 00
    let rem = d
    for (let i = 0; i < 10; i++) rem = (rem << 1) ^ ((rem >>> 9) * 0x537)
    return ((d << 10) | rem) ^ 0x5412
  }
  const drawFormat = (mask: number) => {
    const bits15 = formatBits(mask)
    const bit = (i: number) => ((bits15 >>> i) & 1) !== 0
    for (let i = 0; i <= 5; i++) set(8, i, bit(i))
    set(8, 7, bit(6))
    set(8, 8, bit(7))
    set(7, 8, bit(8))
    for (let i = 9; i < 15; i++) set(14 - i, 8, bit(i))
    for (let i = 0; i < 8; i++) set(size - 1 - i, 8, bit(i))
    for (let i = 8; i < 15; i++) set(8, size - 15 + i, bit(i))
    set(8, size - 8, true)
  }
  drawFormat(0)
  if (version >= 7) {
    let rem = version
    for (let i = 0; i < 12; i++) rem = (rem << 1) ^ ((rem >>> 11) * 0x1f25)
    const vb = (version << 12) | rem
    for (let i = 0; i < 18; i++) {
      const dark = ((vb >>> i) & 1) !== 0
      const a = size - 11 + (i % 3), b = Math.floor(i / 3)
      set(a, b, dark)
      set(b, a, dark)
    }
  }

  // 4) posiciona dados em zigue-zague
  let bi = 0
  for (let right = size - 1; right >= 1; right -= 2) {
    if (right === 6) right = 5
    for (let vert = 0; vert < size; vert++)
      for (let j = 0; j < 2; j++) {
        const x = right - j
        const upward = ((right + 1) & 2) === 0
        const y = upward ? size - 1 - vert : vert
        if (!fn[y][x] && bi < codewords.length * 8) {
          mod[y][x] = ((codewords[bi >>> 3] >>> (7 - (bi & 7))) & 1) !== 0
          bi++
        }
      }
  }

  // 5) máscara com menor penalidade
  const MASKS: ((x: number, y: number) => boolean)[] = [
    (x, y) => (x + y) % 2 === 0,
    (_x, y) => y % 2 === 0,
    x => x % 3 === 0,
    (x, y) => (x + y) % 3 === 0,
    (x, y) => (Math.floor(x / 3) + Math.floor(y / 2)) % 2 === 0,
    (x, y) => ((x * y) % 2) + ((x * y) % 3) === 0,
    (x, y) => (((x * y) % 2) + ((x * y) % 3)) % 2 === 0,
    (x, y) => (((x + y) % 2) + ((x * y) % 3)) % 2 === 0,
  ]
  const applyMask = (m: number) => {
    for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) if (!fn[y][x] && MASKS[m](x, y)) mod[y][x] = !mod[y][x]
  }
  const penalty = (): number => {
    let p = 0
    const lines: string[] = []
    for (let y = 0; y < size; y++) lines.push(mod[y].map(c => (c ? '1' : '0')).join(''))
    for (let x = 0; x < size; x++) lines.push(mod.map(r => (r[x] ? '1' : '0')).join(''))
    for (const l of lines) {
      const runs = l.match(/0+|1+/g) ?? []
      for (const r of runs) if (r.length >= 5) p += 3 + (r.length - 5)
      for (const pat of ['10111010000', '00001011101']) {
        let i = l.indexOf(pat)
        while (i >= 0) {
          p += 40
          i = l.indexOf(pat, i + 1)
        }
      }
    }
    for (let y = 0; y < size - 1; y++)
      for (let x = 0; x < size - 1; x++) {
        const c = mod[y][x]
        if (c === mod[y][x + 1] && c === mod[y + 1][x] && c === mod[y + 1][x + 1]) p += 3
      }
    let dark = 0
    for (const r of mod) for (const c of r) if (c) dark++
    const total = size * size
    p += Math.floor(Math.abs(dark * 20 - total * 10) / total) * 10 // aproximação padrão (cada 5% de desvio = 10)
    return p
  }
  let best = 0, bestPen = Infinity
  for (let m = 0; m < 8; m++) {
    applyMask(m)
    drawFormat(m)
    const pen = penalty()
    if (pen < bestPen) {
      best = m
      bestPen = pen
    }
    applyMask(m) // desfaz
  }
  applyMask(best)
  drawFormat(best)
  return mod
}

/** Monta o SVG (string) do QR com zona de silêncio de 4 módulos, fundo branco e módulos escuros. */
export function qrSvgString(text: string, px = 512): string {
  const m = qrMatrix(text)
  const n = m.length
  const q = 4
  let d = ''
  for (let y = 0; y < n; y++) {
    let x = 0
    while (x < n) {
      if (!m[y][x]) { x++; continue }
      let e = x
      while (e < n && m[y][e]) e++
      d += `M${x + q} ${y + q}h${e - x}v1h-${e - x}z`
      x = e
    }
  }
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${n + q * 2} ${n + q * 2}" width="${px}" height="${px}" shape-rendering="crispEdges"><rect width="100%" height="100%" fill="#fff"/><path d="${d}" fill="#060B1A"/></svg>`
}
