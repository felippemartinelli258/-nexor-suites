// Usa o ícone oficial derivado do PNG da logo (sem redesenhar a marca).
export function LogoIcon({ size = 34 }: { size?: number }) {
  return <img src="/brand/nexor-icon-192.png" width={size} height={size} alt="Nexor Suítes" style={{ borderRadius: size * 0.26, display: 'block' }} />
}
