import { useMemo } from 'react'
import { qrSvgString } from '../lib/qr'

/** QR real (gerado aqui, escaneável). O texto codificado fica em data-qr-value para conferência. */
export function QrImage({ value, label, className = '' }: { value: string; label: string; className?: string }) {
  const svg = useMemo(() => qrSvgString(value, 512), [value])
  return <div className={`qrimg ${className}`} role="img" aria-label={label} data-qr-value={value} dangerouslySetInnerHTML={{ __html: svg }} />
}

/** Baixa o QR como PNG (1024 px + legenda), pronto para imprimir. */
export async function downloadQr(value: string, caption: string, filename: string): Promise<void> {
  const size = 1024, band = 150
  const url = URL.createObjectURL(new Blob([qrSvgString(value, size)], { type: 'image/svg+xml' }))
  try {
    const img = new Image()
    await new Promise<void>((res, rej) => {
      img.onload = () => res()
      img.onerror = () => rej(new Error('Falha ao gerar a imagem do QR'))
      img.src = url
    })
    const canvas = document.createElement('canvas')
    canvas.width = size
    canvas.height = size + band
    const ctx = canvas.getContext('2d')
    if (!ctx) throw new Error('Canvas indisponível')
    ctx.fillStyle = '#fff'
    ctx.fillRect(0, 0, canvas.width, canvas.height)
    ctx.imageSmoothingEnabled = false
    ctx.drawImage(img, 0, 0, size, size)
    ctx.fillStyle = '#060B1A'
    ctx.textAlign = 'center'
    ctx.font = '700 54px system-ui, sans-serif'
    ctx.fillText(caption, size / 2, size + 30)
    ctx.fillStyle = '#51618F'
    ctx.font = '400 30px system-ui, sans-serif'
    ctx.fillText('Aponte a câmera do celular', size / 2, size + 82)
    const blob = await new Promise<Blob | null>(res => canvas.toBlob(res, 'image/png'))
    if (!blob) throw new Error('Falha ao exportar o PNG')
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = filename
    document.body.appendChild(a)
    a.click()
    a.remove()
    setTimeout(() => URL.revokeObjectURL(a.href), 4000)
  } finally {
    URL.revokeObjectURL(url)
  }
}
