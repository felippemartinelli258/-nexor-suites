import type { ReactNode } from 'react'
import { Link, usePath } from '../router'
import { LogoIcon } from './Brand'
import { TENANT } from '../data/seed'
import { restoreDemo } from '../data/store'
import { InstallButton } from './InstallButton'

export const NAV = [
  { to: '/', icon: '◉', label: 'Dashboard', group: 'Visão geral' },
  { to: '/solicitacoes', icon: '✉', label: 'Solicitações', group: 'Operação' },
  { to: '/governanca', icon: '✧', label: 'Governança', group: 'Operação' },
  { to: '/manutencao', icon: '⚙', label: 'Manutenção', group: 'Operação' },
  { to: '/quartos', icon: '▦', label: 'Quartos', group: 'Operação' },
  { to: '/reservas', icon: '❖', label: 'Reservas', group: 'Operação' },
  { to: '/hospede', icon: '☾', label: 'Hóspede', group: 'Experiência' },
  { to: '/qr-codes', icon: '▣', label: 'QR Codes', group: 'Experiência' },
]

const GROUPS = ['Visão geral', 'Operação', 'Experiência'] as const

export function Shell({ children }: { children: ReactNode }) {
  const path = usePath()
  return (
    <>
      <div className="app">
        <nav className="side">
          <div className="brand">
            <LogoIcon />
            <div className="bt">
              NEXOR<small>SUÍTES</small>
            </div>
          </div>
          {GROUPS.map(g => (
            <div key={g} className="nav-group">
              <small className="nav-label">{g}</small>
              {NAV.filter(n => n.group === g).map(n => (
                <Link key={n.to} to={n.to} className={`nb ${path === n.to ? 'on' : ''}`} aria-current={path === n.to ? 'page' : undefined}>
                  <span>{n.icon}</span>
                  {n.label}
                </Link>
              ))}
            </div>
          ))}
          <div className="tenant">
            <div className="tn-row"><b>{TENANT.name}</b><span className="demo-pill" data-testid="demo-pill">Demo</span></div>
            {TENANT.loc}
            <br />
            ID: {TENANT.id}
            <button type="button" className="btn ghost sm" style={{ marginTop: 10, width: '100%' }} onClick={() => restoreDemo()}>
              Restaurar demonstração
            </button>
            <InstallButton className="btn ghost sm install-side" />
          </div>
        </nav>
        <main key={path}>{children}</main>
      </div>
      <div className="mob">
        {NAV.map(n => (
          <Link key={n.to} to={n.to} className={path === n.to ? 'on' : ''}>
            <b>{n.icon}</b>
            {n.label}
          </Link>
        ))}
      </div>
    </>
  )
}
