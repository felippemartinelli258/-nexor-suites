import { useEffect, useState } from 'react'
import { useDemo, setRoomStatus, checkOut } from '../data/store'
import { ROOM_LABEL, RES_LABEL, categoryOf, guestById, kpis, requestsOf, reservationTotal, roomByNum, stayOf } from '../data/selectors'
import { brl, fmtFull, nights } from '../lib/dates'
import type { CategoryId, RoomStatus } from '../types'

export function RoomMap({ category = 'todos' }: { category?: CategoryId | 'todos' }) {
  const s = useDemo()
  const [open, setOpen] = useState<string | null>(null)
  const list = s.rooms.filter(r => category === 'todos' || r.category === category)
  return (
    <>
      <div className="rm">
        {list.map(r => {
          const stay = r.status === 'o' ? stayOf(s, r.num) : undefined
          const first = stay ? (guestById(s, stay.guestId)?.name.split(' ')[0] ?? '') : ''
          return (
            <button key={r.num} type="button" className={`r ${r.status}`} data-room={r.num} onClick={() => setOpen(r.num)}>
              <b>{r.num}</b>
              <span>{ROOM_LABEL[r.status]}</span>
              <small>{first || '\u00a0'}</small>
            </button>
          )
        })}
      </div>
      {open && <RoomDialog num={open} onClose={() => setOpen(null)} />}
    </>
  )
}

export function Legend() {
  const k = kpis(useDemo())
  return (
    <div className="lg">
      <span><i style={{ background: '#2A4FD0' }} />Ocupado {k.occupied}</span>
      <span><i style={{ background: 'var(--ok)' }} />Livre {k.free}</span>
      <span><i style={{ background: 'var(--wa)' }} />Limpeza {k.cleaning}</span>
      <span><i style={{ background: 'var(--er)' }} />Manutenção {k.maintenance}</span>
    </div>
  )
}

const CHANGE: { to: RoomStatus; label: string }[] = [
  { to: 'v', label: 'Marcar como Livre' },
  { to: 'l', label: 'Enviar para Limpeza' },
  { to: 'm', label: 'Colocar em Manutenção' },
]

function RoomDialog({ num, onClose }: { num: string; onClose: () => void }) {
  const s = useDemo()
  const [msg, setMsg] = useState('')
  useEffect(() => {
    const on = (e: KeyboardEvent) => e.key === 'Escape' && onClose()
    window.addEventListener('keydown', on)
    return () => window.removeEventListener('keydown', on)
  }, [onClose])
  const room = roomByNum(s, num)
  if (!room) return null
  const cat = categoryOf(room)
  const stay = stayOf(s, num)
  const guest = stay ? guestById(s, stay.guestId) : undefined
  const reqs = requestsOf(s, num)
  const next = s.reservations
    .filter(r => r.room === num && (r.status === 'confirmada' || r.status === 'pre'))
    .sort((a, b) => a.checkIn.localeCompare(b.checkIn))[0]
  return (
    <div className="ov" onClick={onClose}>
      <div className="dlg" role="dialog" aria-label={`Quarto ${num}`} onClick={e => e.stopPropagation()}>
        <div className="dh">
          <div>
            <h2>Quarto {num}</h2>
            <small>{cat.name} · diária {brl(cat.price)}</small>
          </div>
          <span className={`chip ${{ o: 'a', v: 'g', l: 'w', m: 'e' }[room.status]}`}>{ROOM_LABEL[room.status]}</span>
        </div>
        {stay && guest && (
          <div className="box">
            <b>{guest.name}</b>
            <small>{guest.phone}</small>
            <small>
              {fmtFull(stay.checkIn)} → {fmtFull(stay.checkOut)} · {nights(stay.checkIn, stay.checkOut)} noites · {brl(reservationTotal(s, stay))}
            </small>
            <small>{RES_LABEL[stay.status]}</small>
          </div>
        )}
        {reqs.length > 0 && (
          <div className="box">
            <b>Solicitações abertas</b>
            {reqs.map(q => (
              <small key={q.id}>• {q.title}{q.urgent ? ' (urgente)' : ''}</small>
            ))}
          </div>
        )}
        {!stay && next && (
          <div className="box">
            <b>Próxima reserva</b>
            <small>{guestById(s, next.guestId)?.name} · {fmtFull(next.checkIn)} → {fmtFull(next.checkOut)} · {RES_LABEL[next.status]}</small>
          </div>
        )}
        <div className="acts">
          {stay ? (
            <button className="btn" onClick={() => setMsg(checkOut(stay.id).message)}>Fazer check-out</button>
          ) : (
            CHANGE.filter(c => c.to !== room.status).map(c => (
              <button key={c.to} className="btn ghost" onClick={() => setMsg(setRoomStatus(num, c.to).message)}>{c.label}</button>
            ))
          )}
        </div>
        {msg && <div className="toast">{msg}</div>}
        <button className="btn ghost close" onClick={onClose}>Fechar</button>
      </div>
    </div>
  )
}
