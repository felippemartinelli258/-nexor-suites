import { useInstall } from '../lib/pwa'

/** Botão discreto de instalação. Só aparece quando o navegador oferece instalar; nunca é um popup. */
export function InstallButton({ className = 'btn ghost sm' }: { className?: string }) {
  const { canInstall, install } = useInstall()
  if (!canInstall) return null
  return (
    <button type="button" className={className} onClick={() => install()} data-testid="install-app" title="Instalar Nexor Suítes como aplicativo">
      Instalar app
    </button>
  )
}
