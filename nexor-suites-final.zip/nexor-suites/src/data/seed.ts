// Dados iniciais do demo — Pousada Mar Azul. Única fonte de verdade: a store (store.ts) parte daqui.
// Hoje (demo) = 10/10/2026. Os números do Dashboard são CALCULADOS a partir destas entidades.
import type { Activity, Category, CategoryId, DemoState, Guest, GuestRequest, Reservation, ReservationStatus, Room, RoomStatus, Task } from '../types'

export const SCHEMA_VERSION = 2

export const TENANT = {
  id: 'demo-mar-azul',
  slug: 'mar-azul', // usado na URL pública do hóspede: /guest/mar-azul/room/204
  name: 'Pousada Mar Azul',
  loc: 'Guriri, São Mateus - ES',
  manager: 'Helena Duarte', // administradora (NÃO é hóspede)
}

// Quarto usado na prévia do hóspede e no QR de exemplo (o 204 é o quarto da Mariana Costa).
export const DEMO_ROOM = '204'

export const CATEGORIES: Category[] = [
  { id: 'standard', name: 'Suíte Standard', price: 280 },
  { id: 'deluxe', name: 'Suíte Deluxe', price: 360 },
  { id: 'familia', name: 'Suíte Família', price: 520 },
  { id: 'premium', name: 'Suíte Premium', price: 640 },
]

const LAYOUT: [CategoryId, string[]][] = [
  ['standard', ['101', '102', '103', '104', '105', '106', '107', '108']],
  ['deluxe', ['201', '202', '203', '204', '205', '206', '207', '208', '209', '210']],
  ['familia', ['301', '302', '303', '304', '305', '306']],
  ['premium', ['401', '402', '403', '404']],
]

// Status inicial dos quartos que NÃO estão ocupados (os ocupados vêm das reservas "hospedado").
const NON_OCCUPIED: Record<string, RoomStatus> = {
  '103': 'v', '303': 'v', '402': 'v', // livres, aguardando chegada hoje
  '106': 'v', // livre (check-out de hoje já limpo)
  '108': 'l', '205': 'l', // limpeza (check-out de hoje)
  '207': 'm', // manutenção
}

// [nome, quarto, check-in, check-out, status, hora-in, hora-out]
type Row = [string, string, string, string, ReservationStatus, string, string]
const H: ReservationStatus = 'hospedado'
const C: ReservationStatus = 'confirmada'
const F: ReservationStatus = 'finalizada'
const P: ReservationStatus = 'pre'
const ROWS: Row[] = [
  // check-ins de hoje já realizados (5)
  ['Mariana Costa', '204', '2026-10-10', '2026-10-13', H, '12:40', '12:00'],
  ['Lucas Ferreira', '301', '2026-10-10', '2026-10-14', H, '13:10', '12:00'],
  ['Henrique Dias', '401', '2026-10-10', '2026-10-13', H, '11:50', '12:00'],
  ['Aline Barros', '104', '2026-10-10', '2026-10-12', H, '13:30', '12:00'],
  ['Gustavo Rocha', '209', '2026-10-10', '2026-10-12', H, '12:15', '12:00'],
  // check-ins de hoje pendentes (3)
  ['Camila Souza', '303', '2026-10-10', '2026-10-15', C, '14:00', '12:00'],
  ['Juliana Prado', '103', '2026-10-10', '2026-10-14', C, '15:30', '12:00'],
  ['Diego Moreira', '402', '2026-10-10', '2026-10-13', C, '17:00', '12:00'],
  // check-outs de hoje pendentes (2)
  ['Fernanda Lima', '102', '2026-10-07', '2026-10-10', H, '14:00', '12:00'],
  ['Marcelo Freitas', '304', '2026-10-06', '2026-10-10', H, '15:00', '12:00'],
  // check-outs de hoje já feitos (3)
  ['Patrícia Gomes', '108', '2026-10-08', '2026-10-10', F, '14:00', '09:30'],
  ['Renata Teixeira', '205', '2026-10-07', '2026-10-10', F, '14:00', '10:30'],
  ['Felipe Araújo', '106', '2026-10-08', '2026-10-10', F, '14:00', '11:00'],
  // hospedados no meio da estadia (14)
  ['Rafael Almeida', '101', '2026-10-05', '2026-10-12', H, '14:00', '12:00'],
  ['Beatriz Nunes', '105', '2026-10-09', '2026-10-12', H, '14:00', '12:00'],
  ['Thiago Ribeiro', '107', '2026-10-08', '2026-10-11', H, '14:00', '12:00'],
  ['Isabela Cunha', '201', '2026-10-06', '2026-10-13', H, '14:00', '12:00'],
  ['Pedro Martins', '202', '2026-10-09', '2026-10-14', H, '14:00', '12:00'],
  ['Vanessa Lopes', '203', '2026-10-07', '2026-10-11', H, '14:00', '12:00'],
  ['Larissa Pinto', '206', '2026-09-30', '2026-10-12', H, '14:00', '12:00'],
  ['Bruno Carvalho', '208', '2026-10-08', '2026-10-15', H, '14:00', '12:00'],
  ['Carolina Mendes', '210', '2026-10-09', '2026-10-12', H, '14:00', '12:00'],
  ['André Siqueira', '302', '2026-10-05', '2026-10-11', H, '14:00', '12:00'],
  ['Letícia Vargas', '305', '2026-10-08', '2026-10-13', H, '14:00', '12:00'],
  ['Rodrigo Bastos', '306', '2026-10-07', '2026-10-14', H, '14:00', '12:00'],
  ['Natália Brandão', '403', '2026-09-30', '2026-10-12', H, '14:00', '12:00'],
  ['Vinícius Lacerda', '404', '2026-10-08', '2026-10-11', H, '14:00', '12:00'],
  // próximas chegadas
  ['Sabrina Oliveira', '205', '2026-10-11', '2026-10-15', C, '14:00', '12:00'],
  ['Eduardo Nogueira', '302', '2026-10-11', '2026-10-14', C, '14:00', '12:00'],
  ['Tatiane Moura', '102', '2026-10-12', '2026-10-16', C, '14:00', '12:00'],
  ['Caio Monteiro', '106', '2026-10-12', '2026-10-15', C, '14:00', '12:00'],
  ['Priscila Azevedo', '401', '2026-10-13', '2026-10-17', C, '14:00', '12:00'],
  ['Otávio Reis', '304', '2026-10-13', '2026-10-18', P, '14:00', '12:00'],
  ['Gabriela Fontes', '108', '2026-10-14', '2026-10-16', P, '14:00', '12:00'],
]

export const REVENUE_NOTE = 'reservas com check-in em outubro'

function build(): DemoState {
  const guests: Guest[] = []
  const reservations: Reservation[] = ROWS.map(([name, room, ci, co, status, tin, tout], i) => {
    const gid = 'g' + String(i + 1).padStart(2, '0')
    guests.push({ id: gid, name, phone: `(27) 99${String(100 + i * 7).padStart(3, '0')}-${String(2000 + i * 131).slice(-4)}` })
    return { id: 'r' + String(i + 1).padStart(2, '0'), guestId: gid, room, checkIn: ci, checkOut: co, checkInTime: tin, checkOutTime: tout, status }
  })
  const occupied = new Set(reservations.filter(r => r.status === 'hospedado').map(r => r.room))
  const rooms: Room[] = []
  for (const [category, nums] of LAYOUT)
    for (const num of nums) rooms.push({ num, category, status: occupied.has(num) ? 'o' : NON_OCCUPIED[num] ?? 'v' })

  const requests: GuestRequest[] = [
    { id: 'q1', room: '204', kind: 'agua', title: 'Água gelada', status: 'nova', urgent: false },
    { id: 'q2', room: '301', kind: 'limpeza', title: 'Limpeza do quarto', status: 'andamento', urgent: false },
    { id: 'q3', room: '105', kind: 'manutencao', title: 'Chuveiro sem água quente', status: 'nova', urgent: true },
    { id: 'q4', room: '306', kind: 'informacao', title: 'Informações de passeios', status: 'nova', urgent: false },
    { id: 'q5', room: '208', kind: 'manutencao', title: 'Ar-condicionado com ruído', status: 'nova', urgent: true },
    { id: 'q6', room: '403', kind: 'toalhas', title: 'Travesseiros extras', status: 'andamento', urgent: false },
    { id: 'q7', room: '101', kind: 'toalhas', title: 'Troca de toalhas', status: 'nova', urgent: false },
    { id: 'q8', room: '203', kind: 'limpeza', title: 'Limpeza do quarto', status: 'concluida', urgent: false },
    { id: 'q9', room: '302', kind: 'informacao', title: 'Horário do café da manhã', status: 'concluida', urgent: false },
  ]
  const tasks: Task[] = [
    { id: 't1', room: '108', kind: 'limpeza', title: 'Limpeza pós check-out', status: 'pendente', since: '2026-10-10' },
    { id: 't2', room: '205', kind: 'limpeza', title: 'Limpeza pós check-out', status: 'andamento', since: '2026-10-10' },
    { id: 't3', room: '207', kind: 'manutencao', title: 'Ar-condicionado', status: 'pendente', since: '2026-10-08' },
  ]
  // Histórico inicial das atividades (ordem cronológica; a tela mostra as mais recentes primeiro).
  const activity: Activity[] = [
    { id: 'a01', time: '08:20', text: 'Solicitação concluída · Limpeza do quarto', room: '203' },
    { id: 'a02', time: '09:30', text: 'Check-out · Patrícia Gomes · enviado para limpeza', room: '108' },
    { id: 'a03', time: '10:30', text: 'Check-out · Renata Teixeira · enviado para limpeza', room: '205' },
    { id: 'a04', time: '11:00', text: 'Check-out · Felipe Araújo · quarto liberado para limpeza', room: '106' },
    { id: 'a05', time: '11:50', text: 'Check-in · Henrique Dias', room: '401' },
    { id: 'a06', time: '12:15', text: 'Check-in · Gustavo Rocha', room: '209' },
    { id: 'a07', time: '12:40', text: 'Check-in · Mariana Costa', room: '204' },
    { id: 'a08', time: '13:10', text: 'Check-in · Lucas Ferreira', room: '301' },
    { id: 'a09', time: '13:30', text: 'Check-in · Aline Barros', room: '104' },
  ]
  return { version: SCHEMA_VERSION, rooms, guests, reservations, requests, tasks, activity }
}

export function createSeed(): DemoState {
  return build()
}
