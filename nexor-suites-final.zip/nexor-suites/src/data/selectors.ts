// Cálculos derivados: nada aqui é número fixo — tudo sai do estado.
import type { Activity, Category, DemoState, GuestRequest, Reservation, Room, Task, TaskStatus } from '../types'
import { CATEGORIES } from './seed'
import { DEMO_TODAY, daysBetween, monthOf, nights } from '../lib/dates'

export const ROOM_LABEL = { o: 'Ocupado', v: 'Livre', l: 'Limpeza', m: 'Manutenção' } as const
export const RES_LABEL = { confirmada: 'Confirmada', pre: 'Pré-reserva', hospedado: 'Hospedado', finalizada: 'Check-out feito' } as const

export const categoryOf = (room: Room): Category => CATEGORIES.find(c => c.id === room.category)!
export const roomByNum = (s: DemoState, num: string) => s.rooms.find(r => r.num === num)
export const guestById = (s: DemoState, id: string) => s.guests.find(g => g.id === id)
export const guestName = (s: DemoState, id: string) => guestById(s, id)?.name ?? '—'

export function reservationTotal(s: DemoState, r: Reservation): number {
  const room = roomByNum(s, r.room)
  return room ? nights(r.checkIn, r.checkOut) * categoryOf(room).price : 0
}

/** Reserva em andamento (hóspede no quarto agora). */
export const stayOf = (s: DemoState, num: string): Reservation | undefined =>
  s.reservations.find(r => r.room === num && r.status === 'hospedado')

export const isOpen = (q: GuestRequest) => q.status !== 'concluida'
export const requestsOf = (s: DemoState, num: string) => s.requests.filter(q => q.room === num && isOpen(q))

export function kpis(s: DemoState, today = DEMO_TODAY) {
  const count = (st: Room['status']) => s.rooms.filter(r => r.status === st).length
  const total = s.rooms.length
  const occupied = count('o')
  const arrivals = s.reservations.filter(r => r.checkIn === today && r.status !== 'pre')
  const departures = s.reservations.filter(r => r.checkOut === today && (r.status === 'hospedado' || r.status === 'finalizada'))
  const open = s.requests.filter(isOpen)
  const revenueMonth = s.reservations
    .filter(r => r.status !== 'pre' && monthOf(r.checkIn) === monthOf(today))
    .reduce((sum, r) => sum + reservationTotal(s, r), 0)
  return {
    total,
    occupied,
    free: count('v'),
    cleaning: count('l'),
    maintenance: count('m'),
    occupancyPct: total ? Math.round((occupied / total) * 100) : 0,
    checkinsToday: arrivals.length,
    checkinsDone: arrivals.filter(r => r.status === 'hospedado').length,
    checkoutsToday: departures.length,
    checkoutsPending: departures.filter(r => r.status === 'hospedado').length,
    revenueMonth,
    openRequests: open.length,
    urgentRequests: open.filter(q => q.urgent).length,
  }
}

export function occupancyByCategory(s: DemoState) {
  return CATEGORIES.map(c => {
    const rooms = s.rooms.filter(r => r.category === c.id)
    const occ = rooms.filter(r => r.status === 'o').length
    return { name: c.name, occupied: occ, total: rooms.length, pct: rooms.length ? Math.round((occ / rooms.length) * 100) : 0 }
  })
}

export interface TimelineItem {
  time: string
  title: string
  detail: string
  done: boolean
}

export function timeline(s: DemoState, today = DEMO_TODAY): TimelineItem[] {
  const items: TimelineItem[] = []
  for (const r of s.reservations) {
    if (r.checkOut === today && (r.status === 'hospedado' || r.status === 'finalizada'))
      items.push({ time: r.checkOutTime, title: `Check-out · ${guestName(s, r.guestId)}`, detail: `Quarto ${r.room}`, done: r.status === 'finalizada' })
    if (r.checkIn === today && r.status !== 'pre')
      items.push({ time: r.checkInTime, title: `Check-in · ${guestName(s, r.guestId)}`, detail: `Quarto ${r.room}`, done: r.status === 'hospedado' })
  }
  for (const t of s.tasks)
    if (t.status !== 'concluida' && t.kind === 'manutencao') items.push({ time: 'Hoje', title: `Manutenção · ${t.title}`, detail: `Quarto ${t.room}`, done: false })
  const key = (t: string) => (/^\d/.test(t) ? t : '99:99')
  return items.sort((a, b) => key(a.time).localeCompare(key(b.time)))
}

export interface Alert {
  tone: 'e' | 'w' | 'a'
  text: string
}

export function alerts(s: DemoState, today = DEMO_TODAY): Alert[] {
  const out: Alert[] = []
  const openTasks = (t: Task) => t.status !== 'concluida'
  for (const t of s.tasks.filter(x => x.kind === 'manutencao' && openTasks(x))) {
    const d = daysBetween(t.since, today)
    out.push({ tone: 'e', text: `Quarto ${t.room} em manutenção há ${d} ${d === 1 ? 'dia' : 'dias'} · ${t.title}` })
  }
  const urgent = s.requests.filter(q => isOpen(q) && q.urgent)
  for (const q of urgent) out.push({ tone: 'e', text: `Urgente · Quarto ${q.room}: ${q.title}` })
  const cleaning = s.tasks.filter(x => x.kind === 'limpeza' && openTasks(x)).length
  if (cleaning) out.push({ tone: 'w', text: `${cleaning} ${cleaning === 1 ? 'quarto aguardando' : 'quartos aguardando'} limpeza` })
  const pending = s.reservations.filter(r => r.checkIn === today && r.status === 'confirmada')
  if (pending.length) out.push({ tone: 'a', text: `${pending.length} ${pending.length === 1 ? 'chegada pendente' : 'chegadas pendentes'} hoje` })
  return out
}

/** Verificações de coerência entre entidades (usadas nos testes e disponíveis para depuração). */
export function integrityProblems(s: DemoState): string[] {
  const p: string[] = []
  const nums = new Set<string>()
  for (const r of s.rooms) {
    if (nums.has(r.num)) p.push(`quarto duplicado ${r.num}`)
    nums.add(r.num)
    if (!CATEGORIES.some(c => c.id === r.category)) p.push(`categoria inválida no quarto ${r.num}`)
    const stays = s.reservations.filter(x => x.room === r.num && x.status === 'hospedado')
    if (r.status === 'o' && stays.length !== 1) p.push(`quarto ${r.num} ocupado com ${stays.length} estadias`)
    if (r.status !== 'o' && stays.length) p.push(`quarto ${r.num} (${ROOM_LABEL[r.status]}) tem hóspede hospedado`)
  }
  for (const res of s.reservations) {
    if (!roomByNum(s, res.room)) p.push(`reserva ${res.id} aponta para quarto inexistente`)
    if (!guestById(s, res.guestId)) p.push(`reserva ${res.id} aponta para hóspede inexistente`)
    if (nights(res.checkIn, res.checkOut) < (res.status === 'finalizada' ? 0 : 1)) p.push(`reserva ${res.id} com datas inválidas`)
  }
  const active = s.reservations.filter(r => r.status !== 'finalizada')
  for (let i = 0; i < active.length; i++)
    for (let j = i + 1; j < active.length; j++) {
      const a = active[i], b = active[j]
      if (a.room === b.room && a.checkIn < b.checkOut && b.checkIn < a.checkOut) p.push(`sobreposição no quarto ${a.room}: ${a.id} x ${b.id}`)
    }
  for (const q of s.requests) if (!roomByNum(s, q.room)) p.push(`solicitação ${q.id} aponta para quarto inexistente`)
  for (const t of s.tasks) if (!roomByNum(s, t.room)) p.push(`tarefa ${t.id} aponta para quarto inexistente`)
  for (const r of s.rooms.filter(x => x.status === 'l'))
    if (!s.tasks.some(t => t.room === r.num && t.kind === 'limpeza' && t.status !== 'concluida')) p.push(`quarto ${r.num} em limpeza sem tarefa de limpeza`)
  for (const r of s.rooms.filter(x => x.status === 'm'))
    if (!s.tasks.some(t => t.room === r.num && t.kind === 'manutencao' && t.status !== 'concluida')) p.push(`quarto ${r.num} em manutenção sem ordem de manutenção`)
  return p
}

// ---------- Etapa 4: solicitações, governança, manutenção e atividades (tudo derivado da store) ----------

export const REQ_LABEL = { nova: 'Pendente', andamento: 'Em andamento', concluida: 'Concluído' } as const
export const HK_LABEL: Record<TaskStatus, string> = { pendente: 'Limpeza pendente', andamento: 'Em limpeza', limpo: 'Limpo', inspecao: 'Inspeção', concluida: 'Livre' }
export const MT_LABEL = { pendente: 'Aberto', andamento: 'Em atendimento', concluida: 'Resolvido' } as const

/** Hóspede ligado ao quarto: quem está nele agora, ou quem fez check-out por último. Nunca reservas futuras. */
export function guestOfRoom(s: DemoState, num: string): string {
  const stay = stayOf(s, num)
  if (stay) return guestName(s, stay.guestId)
  const last = s.reservations
    .filter(r => r.room === num && r.status === 'finalizada')
    .sort((a, b) => b.checkOut.localeCompare(a.checkOut))[0]
  return last ? guestName(s, last.guestId) : '—'
}

/** Limpezas abertas (governança), na ordem em que foram criadas. */
export const housekeepingTasks = (s: DemoState) => s.tasks.filter(t => t.kind === 'limpeza' && t.status !== 'concluida')
/** Ordens de manutenção (todas, inclusive resolvidas). */
export const maintenanceTasks = (s: DemoState) => s.tasks.filter(t => t.kind === 'manutencao')

/** Contadores da operação para o Dashboard e telas operacionais. */
export function operations(s: DemoState, today = DEMO_TODAY) {
  const reqs = s.requests
  const hk = housekeepingTasks(s)
  const mt = maintenanceTasks(s)
  const arrivals = s.reservations.filter(r => r.checkIn === today && r.status !== 'pre')
  const departures = s.reservations.filter(r => r.checkOut === today && (r.status === 'hospedado' || r.status === 'finalizada'))
  const open = reqs.filter(isOpen)
  return {
    requests: {
      pending: reqs.filter(q => q.status === 'nova').length,
      inProgress: reqs.filter(q => q.status === 'andamento').length,
      done: reqs.filter(q => q.status === 'concluida').length,
      open: open.length,
      urgent: open.filter(q => q.urgent).length,
    },
    cleaning: {
      pending: hk.filter(t => t.status === 'pendente').length,
      inProgress: hk.filter(t => t.status === 'andamento').length,
      clean: hk.filter(t => t.status === 'limpo').length,
      inspection: hk.filter(t => t.status === 'inspecao').length,
      open: hk.length,
    },
    maintenance: {
      open: mt.filter(t => t.status === 'pendente').length,
      inProgress: mt.filter(t => t.status === 'andamento').length,
      resolved: mt.filter(t => t.status === 'concluida').length,
      active: mt.filter(t => t.status !== 'concluida').length,
    },
    checkins: { total: arrivals.length, done: arrivals.filter(r => r.status === 'hospedado').length },
    checkouts: { total: departures.length, done: departures.filter(r => r.status === 'finalizada').length },
  }
}

/** Atividades recentes, mais novas primeiro. */
export const recentActivity = (s: DemoState, n = 8): Activity[] => (s.activity ?? []).slice(-n).reverse()
