// Store local do demo: estado único em memória + persistência em localStorage. Sem backend.
import { useSyncExternalStore } from 'react'
import type { DemoState, GuestRequest, RequestKind, RoomStatus, Task, TaskStatus } from '../types'
import { DEMO_TODAY } from '../lib/dates'
import { SCHEMA_VERSION, createSeed } from './seed'
import { guestName, guestOfRoom, roomByNum, stayOf } from './selectors'

export const STORAGE_KEY = 'nexor-suites:demo'

export interface ActionResult {
  ok: boolean
  message: string
}
const ok = (message: string): ActionResult => ({ ok: true, message })
const fail = (message: string): ActionResult => ({ ok: false, message })

function storage(): Storage | null {
  try {
    return typeof localStorage === 'undefined' ? null : localStorage
  } catch {
    return null
  }
}

function isValid(x: unknown): x is DemoState {
  const s = x as DemoState
  return (
    !!s && typeof s === 'object' && s.version === SCHEMA_VERSION &&
    Array.isArray(s.rooms) && s.rooms.length > 0 && Array.isArray(s.guests) &&
    Array.isArray(s.reservations) && Array.isArray(s.requests) && Array.isArray(s.tasks)
  )
}

function load(): DemoState {
  try {
    const raw = storage()?.getItem(STORAGE_KEY)
    if (raw) {
      const parsed = JSON.parse(raw)
      // Migração suave: dados salvos na Etapa 3 não têm o histórico de atividades.
      if (isValid(parsed)) return { ...parsed, activity: Array.isArray(parsed.activity) ? parsed.activity : [] }
    }
  } catch {
    /* dados corrompidos: volta ao seed */
  }
  return createSeed()
}

let state: DemoState = load()
const listeners = new Set<() => void>()

function commit(next: DemoState) {
  state = next
  try {
    storage()?.setItem(STORAGE_KEY, JSON.stringify(state))
  } catch {
    /* sem persistência (modo privado/cheio): segue só em memória */
  }
  listeners.forEach(l => l())
}

export const getState = () => state
export function subscribe(l: () => void) {
  listeners.add(l)
  return () => listeners.delete(l)
}
export const useDemo = (): DemoState => useSyncExternalStore(subscribe, getState, getState)

/** Recarrega o estado a partir do armazenamento (usado em testes e na sincronização entre abas). */
export function reloadFromStorage() {
  state = load()
  listeners.forEach(l => l())
}
if (typeof window !== 'undefined')
  window.addEventListener('storage', e => {
    if (e.key === STORAGE_KEY) reloadFromStorage()
  })

let seq = 100
const nextId = (p: string) => `${p}${Date.now().toString(36)}${seq++}`

/** Horário local HH:MM para o registro de atividades. */
const nowHHMM = () => {
  const d = new Date()
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`
}

/** Acrescenta uma atividade ao estado (sem commit). */
const logged = (s: DemoState, text: string, room?: string): DemoState => ({
  ...s,
  activity: [...s.activity, { id: nextId('a'), time: nowHHMM(), text, ...(room ? { room } : {}) }],
})

// ---------- ações ----------

export function restoreDemo(): ActionResult {
  commit(createSeed())
  return ok('Demonstração restaurada ao estado inicial.')
}

/**
 * Mantém o quarto coerente com as ordens de manutenção abertas:
 * Livre + ordem aberta → Manutenção; Manutenção sem ordem aberta → Livre.
 * Não mexe em quartos ocupados ou em limpeza.
 */
function syncMaintenanceRoom(s: DemoState, num: string): DemoState {
  const room = roomByNum(s, num)
  if (!room) return s
  const open = s.tasks.some(t => t.room === num && t.kind === 'manutencao' && t.status !== 'concluida')
  let status: RoomStatus = room.status
  if (room.status === 'v' && open) status = 'm'
  if (room.status === 'm' && !open) status = 'v'
  if (status === room.status) return s
  return { ...s, rooms: s.rooms.map(r => (r.num === num ? { ...r, status } : r)) }
}

export function setRoomStatus(num: string, status: RoomStatus): ActionResult {
  const room = roomByNum(state, num)
  if (!room) return fail('Quarto não encontrado.')
  if (status === 'o') return fail('Para ocupar um quarto, faça o check-in de uma reserva.')
  if (room.status === 'o') return fail('Quarto ocupado: faça o check-out antes de alterar o estado.')
  if (room.status === status) return ok('Sem alteração.')
  let tasks: Task[] = state.tasks
  const close = (kind: Task['kind']) => (tasks = tasks.map(t => (t.room === num && t.kind === kind && t.status !== 'concluida' ? { ...t, status: 'concluida' as TaskStatus } : t)))
  const open = (kind: Task['kind'], title: string) => {
    if (!tasks.some(t => t.room === num && t.kind === kind && t.status !== 'concluida'))
      tasks = [...tasks, { id: nextId('t'), room: num, kind, title, status: 'pendente', since: DEMO_TODAY }]
  }
  if (room.status === 'l') close('limpeza')
  if (room.status === 'm') close('manutencao')
  if (status === 'l') open('limpeza', 'Limpeza')
  if (status === 'm') open('manutencao', 'Manutenção')
  const label = { v: 'Livre', l: 'em Limpeza', m: 'em Manutenção', o: 'Ocupado' }[status]
  const next = logged({ ...state, rooms: state.rooms.map(r => (r.num === num ? { ...r, status } : r)), tasks }, `Quarto ${num} agora está ${label}`, num)
  commit(next)
  return ok(`Quarto ${num} agora está ${label}.`)
}

export function checkIn(reservationId: string): ActionResult {
  const res = state.reservations.find(r => r.id === reservationId)
  if (!res) return fail('Reserva não encontrada.')
  if (res.status !== 'confirmada') return fail('Só reservas confirmadas podem fazer check-in.')
  if (res.checkIn > DEMO_TODAY) return fail('Esta reserva ainda não chegou.')
  const room = roomByNum(state, res.room)
  if (!room || room.status !== 'v') return fail(`Quarto ${res.room} não está livre para o check-in.`)
  const next = logged(
    {
      ...state,
      reservations: state.reservations.map(r => (r.id === res.id ? { ...r, status: 'hospedado' } : r)),
      rooms: state.rooms.map(r => (r.num === res.room ? { ...r, status: 'o' } : r)),
    },
    `Check-in · ${guestName(state, res.guestId)} · quarto ${res.room} ocupado`,
    res.room,
  )
  commit(next)
  return ok(`Check-in feito no quarto ${res.room}.`)
}

export function checkOut(reservationId: string): ActionResult {
  const res = state.reservations.find(r => r.id === reservationId)
  if (!res || res.status !== 'hospedado') return fail('Estadia não encontrada.')
  const next = logged(
    {
      ...state,
      reservations: state.reservations.map(r => (r.id === res.id ? { ...r, status: 'finalizada', checkOut: r.checkOut > DEMO_TODAY ? DEMO_TODAY : r.checkOut } : r)),
      rooms: state.rooms.map(r => (r.num === res.room ? { ...r, status: 'l' } : r)),
      requests: state.requests.map(q => (q.room === res.room && q.status !== 'concluida' ? { ...q, status: 'concluida' } : q)),
      tasks: [...state.tasks, { id: nextId('t'), room: res.room, kind: 'limpeza', title: 'Limpeza pós check-out', status: 'pendente', since: DEMO_TODAY }],
    },
    `Check-out · ${guestName(state, res.guestId)} · quarto ${res.room} em limpeza`,
    res.room,
  )
  commit(next)
  return ok(`Check-out feito. Quarto ${res.room} enviado para limpeza.`)
}

// ---------- governança (limpeza) ----------

/** Ordem de avanço da governança: Limpeza pendente → Em limpeza → Limpo → Inspeção → Livre. */
const HK_LABEL: Record<TaskStatus, string> = { pendente: 'Limpeza pendente', andamento: 'Em limpeza', limpo: 'Limpo', inspecao: 'Inspeção', concluida: 'Livre' }

/**
 * Move a limpeza de um quarto pela governança. Regras:
 * - Liberar (concluida → quarto Livre) só a partir de Limpo ou Inspeção.
 * - Inspeção só a partir de Limpo.
 * - Qualquer estado aberto pode voltar para Em limpeza (ex.: reprovado na inspeção).
 */
export function setHousekeeping(taskId: string, to: TaskStatus): ActionResult {
  const task = state.tasks.find(t => t.id === taskId && t.kind === 'limpeza')
  if (!task) return fail('Limpeza não encontrada.')
  if (task.status === 'concluida') return fail('Este quarto já está livre.')
  if (task.status === to) return ok('Sem alteração.')
  if (to === 'concluida') {
    if (task.status !== 'limpo' && task.status !== 'inspecao') return fail('Libere o quarto somente depois de marcar como Limpo.')
    const room = roomByNum(state, task.room)
    if (!room || room.status !== 'l') return fail(`Quarto ${task.room} não está em limpeza.`)
    const next = logged(
      {
        ...state,
        tasks: state.tasks.map(t => (t.id === taskId ? { ...t, status: 'concluida' } : t)),
        rooms: state.rooms.map(r => (r.num === task.room ? { ...r, status: 'v' } : r)),
      },
      `Quarto ${task.room} liberado · Livre`,
      task.room,
    )
    commit(next)
    return ok(`Quarto ${task.room} está Livre.`)
  }
  if (to === 'inspecao' && task.status !== 'limpo') return fail('Envie para inspeção somente depois de marcar como Limpo.')
  commit(logged({ ...state, tasks: state.tasks.map(t => (t.id === taskId ? { ...t, status: to } : t)) }, `Quarto ${task.room}: ${HK_LABEL[to]}`, task.room))
  return ok(`Quarto ${task.room}: ${HK_LABEL[to]}.`)
}

// ---------- manutenção ----------

const MT_LABEL: Record<'pendente' | 'andamento' | 'concluida', string> = { pendente: 'Aberto', andamento: 'Em atendimento', concluida: 'Resolvido' }

export function setMaintenance(taskId: string, to: 'pendente' | 'andamento' | 'concluida'): ActionResult {
  const task = state.tasks.find(t => t.id === taskId && t.kind === 'manutencao')
  if (!task) return fail('Ordem de manutenção não encontrada.')
  if (task.status === to) return ok('Sem alteração.')
  let next: DemoState = logged(
    { ...state, tasks: state.tasks.map(t => (t.id === taskId ? { ...t, status: to } : t)) },
    `Manutenção · ${task.title} · quarto ${task.room}: ${MT_LABEL[to]}`,
    task.room,
  )
  next = syncMaintenanceRoom(next, task.room)
  commit(next)
  return ok(`Manutenção ${MT_LABEL[to].toLowerCase()}.`)
}

export function openMaintenance(room: string, title: string): ActionResult {
  const clean = title.trim().slice(0, 120)
  if (!roomByNum(state, room)) return fail('Escolha um quarto válido.')
  if (!clean) return fail('Descreva o problema.')
  let next: DemoState = {
    ...state,
    tasks: [...state.tasks, { id: nextId('t'), room, kind: 'manutencao', title: clean, status: 'pendente', since: DEMO_TODAY }],
  }
  next = logged(next, `Nova ordem de manutenção · ${clean} · quarto ${room}`, room)
  next = syncMaintenanceRoom(next, room)
  commit(next)
  return ok('Ordem de manutenção aberta.')
}

// ---------- solicitações ----------

export function setRequestStatus(id: string, status: GuestRequest['status']): ActionResult {
  const q = state.requests.find(x => x.id === id)
  if (!q) return fail('Solicitação não encontrada.')
  if (q.status === status) return ok('Sem alteração.')
  const label = { nova: 'Pendente', andamento: 'Em andamento', concluida: 'Concluído' }[status]
  commit(logged({ ...state, requests: state.requests.map(x => (x.id === id ? { ...x, status } : x)) }, `Solicitação · ${q.title} · quarto ${q.room}: ${label}`, q.room))
  return ok(status === 'concluida' ? 'Solicitação concluída.' : 'Solicitação atualizada.')
}

/** Transforma uma solicitação de manutenção em ordem de manutenção e a coloca em andamento. */
export function requestToMaintenance(id: string): ActionResult {
  const q = state.requests.find(x => x.id === id)
  if (!q) return fail('Solicitação não encontrada.')
  if (q.status === 'concluida') return fail('Solicitação já concluída.')
  let next: DemoState = {
    ...state,
    requests: state.requests.map(x => (x.id === id ? { ...x, status: 'andamento' } : x)),
    tasks: [...state.tasks, { id: nextId('t'), room: q.room, kind: 'manutencao', title: q.note ? q.note : q.title.replace(/^Manutenção: /, ''), status: 'pendente', since: DEMO_TODAY, origin: 'Solicitação do hóspede', guest: guestOfRoom(state, q.room) }],
  }
  next = logged(next, `Solicitação virou ordem de manutenção · quarto ${q.room}`, q.room)
  next = syncMaintenanceRoom(next, q.room)
  commit(next)
  return ok('Ordem de manutenção criada a partir da solicitação.')
}

export function addRequest(room: string, kind: RequestKind, title: string, urgent = false): ActionResult {
  if (!stayOf(state, room)) return fail('Só quartos com hóspede podem abrir solicitações.')
  if (state.requests.some(q => q.room === room && q.kind === kind && q.status !== 'concluida')) return ok('Já solicitado — a equipe foi avisada.')
  commit({ ...state, requests: [...state.requests, { id: nextId('q'), room, kind, title, status: 'nova', urgent }] })
  return ok('Solicitação enviada — a equipe já foi avisada.')
}

const plural = (n: number, one: string, many: string) => `${n} ${n === 1 ? one : many}`

/** Título legível do pedido (ex.: \"2 toalhas extras\"). */
export function requestTitle(kind: RequestKind, quantity = 1, note = ''): string {
  switch (kind) {
    case 'toalhas': return plural(quantity, 'toalha extra', 'toalhas extras')
    case 'travesseiros': return plural(quantity, 'travesseiro extra', 'travesseiros extras')
    case 'agua': return plural(quantity, 'garrafa de água', 'garrafas de água')
    case 'limpeza': return 'Limpeza do quarto'
    case 'manutencao': return note ? `Manutenção: ${note}` : 'Manutenção solicitada'
    default: return note || 'Pedido do hóspede'
  }
}

/** Pedido feito pelo hóspede na página pública. Sempre cria uma solicitação nova, com status \"nova\" (exibida como Pendente). */
export function submitGuestRequest(room: string, kind: RequestKind, quantity = 1, note = '', title?: string): ActionResult & { id?: string } {
  if (!stayOf(state, room)) return fail('Este quarto não tem hospedagem ativa.')
  const qty = Math.min(20, Math.max(1, Math.floor(quantity) || 1))
  const cleanNote = note.trim().slice(0, 240)
  if (kind === 'outro' && !cleanNote && !title) return fail('Descreva o que você precisa.')
  const id = nextId('q')
  const finalTitle = title ?? requestTitle(kind, qty, cleanNote)
  const q: GuestRequest = {
    id, room, kind,
    title: finalTitle,
    status: 'nova', urgent: false,
    ...(['toalhas', 'travesseiros', 'agua'].includes(kind) ? { quantity: qty } : {}),
    ...(cleanNote ? { note: cleanNote } : {}),
    origin: 'hospede', createdAt: new Date().toISOString(),
  }
  commit(logged({ ...state, requests: [...state.requests, q] }, `Hóspede pediu · ${finalTitle} · quarto ${room}`, room))
  return { ...ok('Pedido enviado — a equipe já foi avisada.'), id }
}
