export type RoomStatus = 'o' | 'v' | 'l' | 'm'
export type CategoryId = 'standard' | 'deluxe' | 'familia' | 'premium'

export interface Category {
  id: CategoryId
  name: string
  price: number
}

export interface Room {
  num: string
  category: CategoryId
  status: RoomStatus
}

export interface Guest {
  id: string
  name: string
  phone: string
}

export type ReservationStatus = 'confirmada' | 'pre' | 'hospedado' | 'finalizada'

export interface Reservation {
  id: string
  guestId: string
  room: string
  checkIn: string // ISO yyyy-mm-dd
  checkOut: string // ISO yyyy-mm-dd
  checkInTime: string // HH:MM
  checkOutTime: string // HH:MM
  status: ReservationStatus
}

export type RequestKind = 'toalhas' | 'limpeza' | 'manutencao' | 'informacao' | 'alimentacao' | 'agua' | 'travesseiros' | 'outro'
/** nova = Pendente · andamento = Em andamento · concluida = Concluído */
export type RequestStatus = 'nova' | 'andamento' | 'concluida'

export interface GuestRequest {
  id: string
  room: string
  kind: RequestKind
  title: string
  status: RequestStatus
  urgent: boolean
  quantity?: number // pedidos do hóspede (Etapa 3)
  note?: string
  origin?: 'hospede'
  createdAt?: string // ISO date-time
}

export type TaskKind = 'limpeza' | 'manutencao'
/**
 * Limpeza (governança): pendente = Limpeza pendente · andamento = Em limpeza · limpo = Limpo · inspecao = Inspeção · concluida = quarto liberado (Livre).
 * Manutenção: pendente = Aberto · andamento = Em atendimento · concluida = Resolvido.
 */
export type TaskStatus = 'pendente' | 'andamento' | 'limpo' | 'inspecao' | 'concluida'

export interface Task {
  id: string
  room: string
  kind: TaskKind
  title: string
  status: TaskStatus
  since: string // ISO date
  /** Origem da ordem de manutenção (Etapa 5): ex. "Solicitação do hóspede". Ausente = registrada pela equipe. */
  origin?: string
  /** Hóspede ligado à origem, quando houver (ex.: Mariana Costa). */
  guest?: string
}

/** Registro das atividades recentes da operação (Etapa 4). */
export interface Activity {
  id: string
  time: string // HH:MM
  text: string
  room?: string
}

export interface DemoState {
  version: number
  rooms: Room[]
  guests: Guest[]
  reservations: Reservation[]
  requests: GuestRequest[]
  tasks: Task[]
  activity: Activity[]
}
