// Teste no navegador (usado no sandbox com Playwright global). Uso: node scripts/sandbox-e2e.mjs [pasta-de-screenshots]
import { createRequire } from 'node:module'
const G = process.env.NPM_GLOBAL || '/home/claude/.npm-global/lib/node_modules'
const { chromium } = createRequire(G + '/')('playwright')
const OUT = process.argv[2] || './screenshots'
const BASE = 'http://localhost:4173'
const browser = await chromium.launch({ executablePath: process.env.CHROME || '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--no-sandbox'] })
let fails = 0, total = 0
const check = (name, cond, extra = '') => { total++; if (!cond) fails++; console.log(cond ? '  ✓' : '  ✗ FALHOU:', name, extra) }

async function session(label, ctxOpts) {
  console.log(`\n== ${label} ==`)
  const ctx = await browser.newContext({ ...ctxOpts, colorScheme: 'dark' })
  const page = await ctx.newPage()
  const errors = []
  page.on('console', m => m.type() === 'error' && errors.push(m.text()))
  page.on('pageerror', e => errors.push(String(e)))
  const tag = label.toLowerCase()
  const N = tag === 'desktop' ? { d: '01-dashboard-desktop', q: '03-quartos-desktop', r: '05-reservas-desktop', x: '07-detalhe-quarto-204-desktop' } : { d: '02-dashboard-mobile', q: '04-quartos-mobile', r: '06-reservas-mobile', x: '08-detalhe-quarto-204-mobile' }
  const base = ctxOpts.viewport
  // página inteira: aumenta a janela até a altura do conteúdo (mantém sidebar/nav fixos no lugar certo); detalhes: janela normal
  const shot = async (n, full = true) => {
    await page.waitForTimeout(600)
    if (full) { await page.setViewportSize({ width: base.width, height: base.height }); const h = await page.evaluate(() => document.documentElement.scrollHeight); await page.setViewportSize({ width: base.width, height: Math.max(h, base.height) }); await page.waitForTimeout(200) }
    await page.screenshot({ path: `${OUT}/${n}.png` })
    await page.setViewportSize(base)
  }

  await page.goto(BASE + '/'); await page.evaluate(() => localStorage.clear()); await page.reload()
  // Dashboard
  const body = () => page.innerText('body')
  let t = await body()
  check('Dashboard: 75% (21/28 calculado)', t.includes('75%') && t.includes('21 de 28 quartos'))
  check('Dashboard: check-ins 8 / check-outs 5 / receita R$ 48.920 / solicitações 7', /Check-ins hoje\s*\n?\s*8/.test(t) && /Check-outs hoje\s*\n?\s*5/.test(t) && t.includes('R$ 48.920') && /Solicitações abertas\s*\n?\s*7/.test(t))
  check('Dashboard: Mariana NÃO é o nome do administrador', /(Bom dia|Boa tarde|Boa noite), Helena\./.test(t) && !/(Bom dia|Boa tarde|Boa noite), Mariana/.test(t))
  check('Dashboard: manutenção no alerta = quarto 207', t.includes('Quarto 207 em manutenção há 2 dias'))
  check('Dashboard: mapa tem 207 em Manutenção', await page.locator('[data-room="207"].m').count() === 1 && await page.locator('[data-room].m').count() === 1)
  await shot(N.d)

  // Quartos
  await page.goto(BASE + '/quartos'); t = await body()
  check('Quartos: 204 ocupado (classe .o) com Mariana', await page.locator('[data-room="204"].o').count() === 1 && (await page.locator('[data-room="204"]').innerText()).includes('Mariana'))
  check('Quartos: 204 NÃO está Livre', !(await page.locator('[data-room="204"]').innerText()).includes('Livre'))
  check('Quartos: 28 quartos', await page.locator('[data-room]').count() === 28)
  check('Quartos: só categorias novas', ['Suíte Standard','Suíte Deluxe','Suíte Família','Suíte Premium'].every(c => t.includes(c)) && !/Superior|Vista Mar|Chalé/.test(t) && !/(^|\n)Standard/.test(t))
  const clipped = await page.evaluate(() => [...document.querySelectorAll('.r span,.r small,.r b')].filter(e => e.scrollWidth > e.clientWidth + 1).length)
  const cardClip = await page.evaluate(() => [...document.querySelectorAll('.r')].filter(e => e.scrollWidth > e.clientWidth + 1).length)
  check('Quartos: texto "Manutenção" e demais NÃO cortados', clipped === 0 && cardClip === 0, `(cortados: ${clipped}/${cardClip})`)
  check('Sem rolagem horizontal', await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth))
  await shot(N.q)
  await page.locator('[data-room="204"]').click()
  check('Detalhe 204: diálogo com Mariana Costa, 10/10/2026 → 13/10/2026', await page.locator('.dlg').innerText().then(x => x.includes('Mariana Costa') && x.includes('10/10/2026') && x.includes('13/10/2026') && x.includes('Ocupado') && x.includes('Suíte Deluxe')))
  await shot(N.x, false)
  await page.keyboard.press('Escape')
  check('Detalhe: fecha com Esc', await page.locator('.dlg').count() === 0)

  // Persistência: 106 Livre -> Limpeza -> reload
  await page.locator('[data-room="106"]').click()
  await page.getByRole('button', { name: 'Enviar para Limpeza' }).click()
  await page.keyboard.press('Escape')
  check('Persistência: 106 em Limpeza', await page.locator('[data-room="106"].l').count() === 1)
  await page.reload()
  check('Persistência: após F5, 106 continua em Limpeza', await page.locator('[data-room="106"].l').count() === 1)
  await page.goto(BASE + '/'); t = await body()
  check('Consistência entre telas: Dashboard reflete 3 em limpeza', /3 em limpeza/.test(t))
  // Restaurar
  const restore = page.getByRole('button', { name: 'Restaurar demonstração' }).first()
  if (await restore.isVisible()) await restore.click(); else { await page.getByRole('button', { name: 'Restaurar demonstração' }).last().click() }
  await page.goto(BASE + '/quartos')
  check('Restauração: 106 volta a Livre e 204 segue ocupado', await page.locator('[data-room="106"].v').count() === 1 && await page.locator('[data-room="204"].o').count() === 1)
  await page.reload()
  check('Restauração persiste após F5', await page.locator('[data-room="106"].v').count() === 1)

  // Reservas
  await page.goto(BASE + '/reservas'); t = await body()
  check('Reservas: Mariana Costa · Quarto 204 · 10/10 → 13/10', t.includes('Mariana Costa') && /Quarto 204[^\n]*10\/10 → 13\/10/.test(t))
  check('Reservas: aba Hoje lista 13 (8 check-ins + 5 check-outs)', /Hoje 13/.test(t))
  check('Reservas: Mariana Hospedado', await page.locator('[data-res]', { hasText: 'Mariana Costa' }).innerText().then(x => x.includes('Hospedado')))
  await shot(N.r)
  // Check-in pendente: Camila (303)
  await page.locator('[data-res]', { hasText: 'Camila Souza' }).getByRole('button', { name: 'Fazer check-in' }).click()
  await page.goto(BASE + '/quartos')
  check('Check-in na Reservas ocupa o 303 no mapa', await page.locator('[data-room="303"].o').count() === 1)
  await page.goto(BASE + '/'); t = await body()
  check('KPIs após check-in: 22 de 28 / 6 já realizados', t.includes('22 de 28 quartos') && t.includes('6 já realizados'))
  await page.getByRole('button', { name: 'Restaurar demonstração' }).first().isVisible().then(async v => v ? page.getByRole('button', { name: 'Restaurar demonstração' }).first().click() : page.getByRole('button', { name: 'Restaurar demonstração' }).last().click())

  // Hóspede / QR
  await page.goto(BASE + '/hospede'); t = await body()
  check('Hóspede (gestão): Mariana Costa, 10/10/2026 → 13/10/2026, rota pública do 204', t.includes('Mariana Costa') && t.includes('10/10/2026') && t.includes('13/10/2026') && t.includes('/guest/mar-azul/room/204'))
  await page.goto(BASE + '/qr-codes'); t = await body()
  check('QR: Quarto 204 e 28 QRs reais', t.includes('Quarto 204') && await page.locator('[data-qr-room]').count() === 28)

  // Navegação
  await page.goto(BASE + '/')
  const nav = ctxOpts.isMobile ? '.mob' : 'nav.side'
  for (const [label, path] of [['Quartos', '/quartos'], ['Reservas', '/reservas'], ['Hóspede', '/hospede'], ['QR Codes', '/qr-codes'], ['Dashboard', '/']]) {
    await page.locator(`${nav} a`, { hasText: label }).click()
    check(`Navegação ${label} → ${path}`, new URL(page.url()).pathname === path)
  }
  await page.goto(BASE + '/reservas'); await page.reload()
  check('Rota direta /reservas funciona após reload', (await body()).includes('Reservas'))
  check('Console sem erros', errors.length === 0, errors.join(' | '))
  await ctx.close()
}

await session('Desktop', { viewport: { width: 1280, height: 900 } })
await session('Mobile', { viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, deviceScaleFactor: 2 })
await browser.close()
console.log(`\n${total - fails}/${total} verificações OK`)
process.exit(fails ? 1 : 0)
