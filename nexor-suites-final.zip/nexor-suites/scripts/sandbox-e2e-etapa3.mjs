// Teste da Etapa 3 no navegador (sandbox, Playwright global). Uso: node scripts/sandbox-e2e-etapa3.mjs [pasta-de-screenshots]
// Decodifica o QR com um leitor real (OpenCV) a partir de PNG renderizado/baixado e abre a URL lida.
import { createRequire } from 'node:module'
import { execFileSync } from 'node:child_process'
import fs from 'node:fs'
const G = process.env.NPM_GLOBAL || '/home/claude/.npm-global/lib/node_modules'
const { chromium } = createRequire(G + '/')('playwright')
const OUT = process.argv[2] || './screenshots'
fs.mkdirSync(OUT, { recursive: true })
const BASE = 'http://localhost:4173'
const ROUTE = '/guest/mar-azul/room/204'
const browser = await chromium.launch({ executablePath: process.env.CHROME || '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--no-sandbox'] })
let fails = 0, total = 0
const check = (name, cond, extra = '') => { total++; if (!cond) fails++; console.log(cond ? '  ✓' : '  ✗ FALHOU:', name, extra) }
const decode = file => execFileSync('python3', ['-c', 'import cv2,sys;v,_,_=cv2.QRCodeDetector().detectAndDecode(cv2.imread(sys.argv[1]));print(v)', file]).toString().trim()

async function open(label, opts) {
  const ctx = await browser.newContext({ ...opts, colorScheme: 'dark', acceptDownloads: true })
  const page = await ctx.newPage()
  const errors = []
  page.on('console', m => m.type() === 'error' && errors.push(m.text()))
  page.on('pageerror', e => errors.push(String(e)))
  console.log(`\n== ${label} ==`)
  return { ctx, page, errors }
}
const body = page => page.innerText('body')
const full = async (page, base, path) => {
  await page.waitForTimeout(700)
  const h = await page.evaluate(() => document.documentElement.scrollHeight)
  await page.setViewportSize({ width: base.width, height: Math.max(h, base.height) })
  await page.waitForTimeout(250)
  await page.screenshot({ path })
  await page.setViewportSize(base)
}

// ---------- DESKTOP ----------
{
  const base = { width: 1280, height: 900 }
  const { ctx, page, errors } = await open('Desktop', { viewport: base })
  await page.goto(BASE + '/'); await page.evaluate(() => localStorage.clear()); await page.reload()

  // QR Codes
  await page.goto(BASE + '/qr-codes')
  const origin = await page.evaluate(() => location.origin)
  const featVal = await page.locator('[data-testid="qr-featured"] [data-qr-value]').getAttribute('data-qr-value')
  check('QR 204 (destaque) aponta para origem atual + /guest/mar-azul/room/204', featVal === origin + ROUTE, featVal)
  check('QR: 28 quartos com QR', await page.locator('[data-qr-room]').count() === 28)
  const vals = await page.$$eval('[data-qr-room]', els => els.map(e => [e.getAttribute('data-qr-room'), e.querySelector('[data-qr-value]').getAttribute('data-qr-value')]))
  check('QR: cada quarto gera /guest/mar-azul/room/<número> (ex.: 205)', vals.every(([n, v]) => v === origin + '/guest/mar-azul/room/' + n) && vals.some(([n]) => n === '205'))
  const t = await body(page)
  check('QR: mostra número, categoria, status e rota', t.includes('Quarto 204') && t.includes('Suíte Deluxe') && t.includes('Ocupado') && t.includes(ROUTE))
  check('QR: sem placeholder ilustrativo', !t.includes('ilustrativo'))
  await page.waitForTimeout(500)
  await full(page, base, `${OUT}/01-qr-codes-desktop.png`)
  // QR renderizado → leitor real
  await page.locator('[data-testid="qr-featured"] .qrimg').screenshot({ path: `${OUT}/qr204-render.png` })
  const dec1 = decode(`${OUT}/qr204-render.png`)
  check('QR escaneado (renderizado na tela) contém a URL correta', dec1 === origin + ROUTE, dec1)
  // origem muda -> QR muda
  const p2 = await ctx.newPage(); await p2.goto('http://127.0.0.1:4173/qr-codes')
  check('QR segue a origem atual (127.0.0.1)', (await p2.locator('[data-testid="qr-featured"] [data-qr-value]').getAttribute('data-qr-value')) === 'http://127.0.0.1:4173' + ROUTE); await p2.close()
  // Visualizar + Baixar
  await page.getByRole('button', { name: 'Visualizar QR' }).click()
  check('Visualizar QR abre diálogo com a URL', (await page.locator('[data-testid="qr-dialog-url"]').innerText()) === origin + ROUTE)
  await page.waitForTimeout(300)
  await page.locator('.qrdlg').screenshot({ path: `${OUT}/02-qr-quarto-204.png` })
  const [dl] = await Promise.all([page.waitForEvent('download'), page.locator('.qrdlg').getByRole('button', { name: 'Baixar QR' }).click()])
  await dl.saveAs(`${OUT}/qr-quarto-204-baixado.png`)
  check('Baixar QR gera qr-quarto-204.png', dl.suggestedFilename() === 'qr-quarto-204.png')
  const dec2 = decode(`${OUT}/qr-quarto-204-baixado.png`)
  check('QR baixado (PNG) escaneado contém a URL correta', dec2 === origin + ROUTE, dec2)
  await page.keyboard.press('Escape')
  check('Diálogo QR fecha com Esc', await page.locator('.qrdlg').count() === 0)
  // categorias
  await page.getByRole('button', { name: /Suíte Premium/ }).click()
  check('Filtro por categoria: Premium = 4 QRs', await page.locator('[data-qr-room]').count() === 4)

  // QR -> rota (abre a URL lida pelo leitor)
  const gp = await ctx.newPage()
  await gp.goto(dec1)
  await gp.waitForSelector('[data-testid="g-hello"]')
  check('QR → rota: URL lida abre a experiência da Mariana no quarto 204', (await gp.innerText('[data-testid="g-hello"]')).includes('Mariana') && (await gp.innerText('[data-testid="g-room"]')).includes('204'))
  await gp.waitForTimeout(900)
  await gp.screenshot({ path: `${OUT}/08-qr-rota-validada.png` })
  await gp.close()

  // Hóspede desktop
  await page.goto(BASE + ROUTE)
  await page.waitForSelector('[data-testid="g-hello"]')
  let g = await body(page)
  check('Desktop hóspede: Olá, Mariana 👋 / Quarto 204 / 10 out → 13 out', g.includes('Olá, Mariana 👋') && g.includes('Quarto 204') && /10 out\s*→\s*13 out/.test(g))
  check('Desktop hóspede: sem sidebar, sem moldura de celular', await page.locator('nav.side, .phone, .mob').count() === 0)
  check('Desktop hóspede: 10 acessos', await page.locator('[data-tile]').count() === 10)
  check('Desktop hóspede: sem rolagem horizontal', await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth))
  await page.waitForTimeout(1200)
  await page.screenshot({ path: `${OUT}/06-hospede-desktop.png` })
  check('Desktop: console sem erros', errors.length === 0, errors.join(' | '))
  await ctx.close()
}

// ---------- MOBILE ----------
{
  const base = { width: 390, height: 844 }
  const { ctx, page, errors } = await open('Mobile', { viewport: base, isMobile: true, hasTouch: true, deviceScaleFactor: 2 })
  await page.goto(BASE + '/'); await page.evaluate(() => localStorage.clear()); await page.reload()
  await page.goto(BASE + ROUTE) // abertura direta
  await page.waitForSelector('[data-testid="g-hello"]')
  check('Rota direta abre sem passar pela gestão', new URL(page.url()).pathname === ROUTE)
  const g = await body(page)
  check('Dados: Mariana Costa, Quarto 204, 10/10/2026 → 13/10/2026', g.includes('Olá, Mariana 👋') && g.includes('Mariana Costa') && g.includes('Quarto 204') && g.includes('10/10/2026 → 13/10/2026') && /10 out\s*→\s*13 out/.test(g))
  check('Mobile: sem sidebar/nav administrativa/moldura', await page.locator('nav.side, .phone, .mob').count() === 0)
  check('Mobile: ocupa a tela inteira (largura 390)', await page.evaluate(() => document.querySelector('.gst').getBoundingClientRect().width === window.innerWidth))
  check('Mobile: sem rolagem horizontal', await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth))
  await page.waitForTimeout(1300)
  await page.screenshot({ path: `${OUT}/03-hospede-mobile-inicio.png` })
  await page.screenshot({ path: `${OUT}/03b-hospede-mobile-inicio-completo.png`, fullPage: true })

  // navegação pelos 10 acessos
  const names = { stay: 'Minha estadia', wifi: 'Wi-Fi', breakfast: 'Café da manhã', pool: 'Piscina', services: 'Serviços', request: 'Solicitar algo', rules: 'Regras da casa', guide: 'Guia local', review: 'Avaliar estadia', checkout: 'Checkout' }
  let navOk = true
  for (const [v, title] of Object.entries(names)) {
    await page.locator(`[data-tile="${v}"]`).click()
    await page.waitForTimeout(150)
    const ok = new URL(page.url()).hash === '#' + v && (await page.locator('.g-back').innerText()).includes(title)
    if (!ok) { navOk = false; console.log('   falhou em', v) }
    await page.locator('.g-back').click()
    if (!(await page.locator('[data-testid="g-hello"]').count())) { navOk = false; console.log('   não voltou de', v) }
  }
  check('Navegação: os 10 acessos abrem e voltam ao início', navOk)

  // solicitação
  await page.locator('[data-testid="g-cta"]').click()
  await page.locator('[data-opt="toalhas"]').click()
  await page.getByRole('button', { name: 'Aumentar' }).click()
  check('Solicitação: quantidade 2 e resumo "2 toalhas extras"', (await page.innerText('[data-testid="g-qty"]')) === '2' && (await page.innerText('[data-testid="g-preview"]')) === '2 toalhas extras')
  await page.waitForTimeout(500)
  await page.screenshot({ path: `${OUT}/04-hospede-mobile-solicitacao.png`, fullPage: true })
  // validação: "Outro pedido" vazio
  await page.locator('[data-opt="outro"]').click()
  await page.locator('[data-testid="g-send"]').click()
  check('Validação: "Outro pedido" vazio mostra erro e não cria nada', (await page.locator('.g-err').count()) === 1 && (await page.evaluate(() => (JSON.parse(localStorage.getItem('nexor-suites:demo') || 'null')?.requests.length ?? 9))) === 9)
  await page.locator('[data-opt="toalhas"]').click()
  await page.getByRole('button', { name: 'Aumentar' }).click()
  await page.locator('[data-testid="g-send"]').click()
  await page.waitForSelector('[data-testid="g-sent"]')
  const sent = await body(page)
  check('Pedido enviado: tela de confirmação com "2 toalhas extras" e Pendente (não é alert)', sent.includes('Pedido enviado') && (await page.innerText('[data-testid="g-sent-title"]')) === '2 toalhas extras' && sent.includes('Pendente'))
  await page.waitForTimeout(700)
  await page.screenshot({ path: `${OUT}/05-hospede-mobile-pedido-enviado.png` })
  const stored = await page.evaluate(() => JSON.parse(localStorage.getItem('nexor-suites:demo')).requests.filter(q => q.origin === 'hospede'))
  check('Store: 1 solicitação criada (204, toalhas, qtd 2, status nova)', stored.length === 1 && stored[0].room === '204' && stored[0].kind === 'toalhas' && stored[0].quantity === 2 && stored[0].status === 'nova' && stored[0].title === '2 toalhas extras')

  // persistência
  await page.goto(BASE + ROUTE)
  await page.waitForSelector('[data-testid="g-hello"]')
  check('Persistência (hóspede): após atualizar, "2 toalhas extras" continua em Seus pedidos', (await page.innerText('[data-testid="g-requests"]')).includes('2 toalhas extras'))

  // gestão
  await page.goto(BASE + '/')
  let t = await body(page)
  check('Gestão: Dashboard mostra Solicitações abertas = 8 (era 7)', /Solicitações abertas\s*\n?\s*8/.test(t))
  const row = page.locator('.row', { hasText: '2 toalhas extras' })
  check('Gestão: solicitação "2 toalhas extras · Quarto 204 · Pendente"', (await row.count()) === 1 && (await row.innerText()).includes('Quarto 204') && (await row.innerText()).includes('Pendente'))
  await page.reload()
  check('Persistência (gestão): após atualizar a página, o pedido continua', (await page.locator('.row', { hasText: '2 toalhas extras' }).count()) === 1)
  await page.goto(BASE + '/hospede')
  check('Gestão /hospede lista o pedido do 204', (await body(page)).includes('2 toalhas extras'))
  await page.goto(BASE + '/quartos'); await page.locator('[data-room="204"]').click()
  check('Detalhe do quarto 204 lista o pedido aberto', (await page.locator('.dlg').innerText()).includes('2 toalhas extras'))
  await page.keyboard.press('Escape')
  await page.goto(BASE + '/')
  await page.waitForTimeout(500)
  await page.screenshot({ path: `${OUT}/07b-gestao-kpis-mobile.png` })
  const card = page.locator('.card', { has: page.getByRole('heading', { name: 'Solicitações de hóspedes' }) })
  await card.scrollIntoViewIfNeeded()
  await card.screenshot({ path: `${OUT}/07-gestao-solicitacao-mobile.png` })

  // reset
  await page.getByRole('button', { name: 'Restaurar demonstração' }).first().isVisible().then(async v => v ? page.getByRole('button', { name: 'Restaurar demonstração' }).first().click() : page.getByRole('button', { name: 'Restaurar demonstração' }).last().click())
  t = await body(page)
  check('Reset: pedido some e KPI volta a 7', !t.includes('2 toalhas extras') && /Solicitações abertas\s*\n?\s*7/.test(t))
  await page.reload()
  check('Reset persiste após atualizar', !(await body(page)).includes('2 toalhas extras'))
  await page.goto(BASE + ROUTE)
  await page.waitForSelector('[data-testid="g-hello"]')
  check('Reset: a página do hóspede também volta ao inicial', !(await body(page)).includes('2 toalhas extras'))

  // casos de borda
  await page.goto(BASE + '/guest/mar-azul/room/999')
  check('Quarto inexistente → "Quarto não encontrado"', (await body(page)).includes('Quarto não encontrado'))
  await page.goto(BASE + '/guest/outra/room/204')
  check('Hospedagem desconhecida → "Quarto não encontrado"', (await body(page)).includes('Quarto não encontrado'))
  await page.goto(BASE + '/guest/mar-azul/room/106')
  check('Quarto sem hóspede (106) → aviso sem pedidos', (await body(page)).includes('não tem hospedagem ativa') && (await page.locator('[data-testid="g-cta"]').count()) === 0)
  await page.goto(BASE + '/guest/mar-azul/room/205/')
  check('Barra final na URL funciona (205 sem hóspede, mas rota válida)', (await body(page)).includes('Quarto 205'))

  // hóspede do 301 (outro quarto)
  await page.goto(BASE + '/guest/mar-azul/room/301'); await page.waitForSelector('[data-testid="g-hello"]')
  check('Outro quarto (301) mostra o hóspede dele: Lucas', (await page.innerText('[data-testid="g-hello"]')).includes('Lucas'))
  check('Mobile: console sem erros', errors.length === 0, errors.join(' | '))
  await ctx.close()
}
await browser.close()
console.log(`\n${total - fails}/${total} verificações OK`)
process.exit(fails ? 1 : 0)
