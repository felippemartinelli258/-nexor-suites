// Teste da Etapa 5 no navegador (sandbox, Playwright global). Uso: node scripts/sandbox-e2e-etapa5.mjs [pasta-de-screenshots]
import { createRequire } from 'node:module'
import fs from 'node:fs'
const G = process.env.NPM_GLOBAL || '/home/claude/.npm-global/lib/node_modules'
const { chromium } = createRequire(G + '/')('playwright')
const OUT = process.argv[2] || './screenshots'
fs.mkdirSync(OUT, { recursive: true })
const BASE = 'http://localhost:4173'
const ROUTE = '/guest/mar-azul/room/204'
const ROUTES = ['/', '/quartos', '/reservas', '/solicitacoes', '/governanca', '/manutencao', '/hospede', '/qr-codes', ROUTE]
const browser = await chromium.launch({ executablePath: process.env.CHROME || '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--no-sandbox'] })
let fails = 0, total = 0
const check = (name, cond, extra = '') => { total++; if (!cond) fails++; console.log(cond ? '  ✓' : '  ✗ FALHOU:', name, extra) }
const body = page => page.innerText('body')
const shot = async (page, file, full = true) => { await page.waitForTimeout(700); await page.screenshot({ path: `${OUT}/${file}`, fullPage: full }) }
const noHScroll = page => page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)

async function session(label, opts) {
  const ctx = await browser.newContext({ ...opts, colorScheme: 'dark' })
  const page = await ctx.newPage()
  const errors = []
  page.on('console', m => m.type() === 'error' && errors.push(m.text()))
  page.on('pageerror', e => errors.push(String(e)))
  console.log(`\n== ${label} ==`)
  return { ctx, page, errors }
}

// ---------- PWA ----------
{
  const { ctx, page, errors } = await session('PWA', { viewport: { width: 1280, height: 900 } })
  await page.goto(BASE + '/')
  await page.evaluate(() => localStorage.clear()); await page.reload()
  await page.waitForSelector('.ops')
  const head = await page.evaluate(() => ({
    manifest: document.querySelector('link[rel="manifest"]')?.getAttribute('href'),
    theme: document.querySelector('meta[name="theme-color"]')?.getAttribute('content'),
    apple: document.querySelector('link[rel="apple-touch-icon"]')?.getAttribute('href'),
    icon: document.querySelector('link[rel="icon"]')?.getAttribute('href'),
  }))
  check('HTML: link do manifest, theme-color, apple-touch-icon e favicon', head.manifest === '/manifest.webmanifest' && !!head.theme && !!head.apple && !!head.icon, JSON.stringify(head))
  const man = await (await page.request.get(BASE + '/manifest.webmanifest')).json()
  check('Manifest: nome e nome curto "Nexor Suítes", display standalone', man.name === 'Nexor Suítes' && man.short_name === 'Nexor Suítes' && man.display === 'standalone')
  check('Manifest: start_url e scope na raiz, cores do tema', man.start_url === '/' && man.scope === '/' && man.background_color === '#060B1A' && man.theme_color === '#060B1A')
  check('Manifest: ícones 192, 512 e maskable 512 (identidade oficial)', man.icons.some(i => i.sizes === '192x192') && man.icons.some(i => i.sizes === '512x512' && i.purpose === 'maskable') && man.icons.some(i => i.sizes === '512x512' && i.purpose === 'any'))
  let iconsOk = true
  for (const i of man.icons) if ((await page.request.get(BASE + i.src)).status() !== 200) iconsOk = false
  check('Ícones do manifest respondem 200', iconsOk)
  check('Service worker responde 200 (sw.js)', (await page.request.get(BASE + '/sw.js')).status() === 200)
  const swState = await page.evaluate(async () => {
    if (!('serviceWorker' in navigator)) return 'unsupported'
    const reg = await navigator.serviceWorker.ready
    return reg.active ? 'active' : 'none'
  })
  check('Service worker registrado e ativo', swState === 'active', swState)
  await page.reload(); await page.waitForSelector('.ops')
  await page.waitForTimeout(500)
  const controlled = await page.evaluate(() => !!navigator.serviceWorker.controller)
  check('Service worker controla a página após recarregar', controlled)
  check('Modo demonstração visível (pill "Demo")', (await page.locator('[data-testid="demo-pill"]').count()) === 1)
  check('Botão Instalar: oculto quando o navegador não oferece instalação (esperado no sandbox)', (await page.locator('[data-testid="install-app"]').count()) === 0)
  await shot(page, '01-dashboard-desktop.png')

  // Offline: a interface principal continua abrindo com dados do localStorage
  await ctx.setOffline(true)
  await page.goto(BASE + '/quartos')
  await page.waitForSelector('.rm', { timeout: 8000 }).catch(() => {})
  check('Offline: /quartos abre a partir do cache do service worker', (await body(page)).includes('Quartos') && (await page.locator('[data-room]').count()) === 28)
  await page.goto(BASE + ROUTE)
  await page.waitForSelector('[data-testid="g-hello"]', { timeout: 8000 }).catch(() => {})
  check('Offline: rota do hóspede 204 abre com Mariana (store/localStorage)', (await body(page)).includes('Olá, Mariana'))
  await ctx.setOffline(false)
  check('Console (PWA): sem erros', errors.length === 0, errors.join(' | '))
  await ctx.close()
}

// ---------- ROTAS DIRETAS, DESKTOP ----------
{
  const { ctx, page, errors } = await session('Rotas diretas (desktop)', { viewport: { width: 1280, height: 900 } })
  await page.goto(BASE + '/'); await page.evaluate(() => localStorage.clear())
  for (const r of ROUTES) {
    await page.goto(BASE + r)
    await page.waitForTimeout(250)
    const t = await body(page)
    const notFound = t.includes('Página não encontrada')
    check(`Abre diretamente ${r}`, !notFound && t.length > 20)
  }
  check('Rotas diretas: console sem erros', errors.length === 0, errors.join(' | '))
  await ctx.close()
}

// ---------- FLUXOS ----------
{
  const { ctx, page, errors } = await session('Fluxos (desktop)', { viewport: { width: 1280, height: 900 } })
  await page.goto(BASE + '/'); await page.evaluate(() => localStorage.clear()); await page.reload()
  await page.waitForSelector('.ops')

  // QR → 204 → Mariana → Solicitar algo → pedido
  await page.goto(BASE + '/qr-codes'); await page.waitForSelector('[data-qr-room]')
  const origin = await page.evaluate(() => location.origin)
  const qrVal = await page.locator('[data-testid="qr-featured"] [data-qr-value]').getAttribute('data-qr-value')
  check('QR 204 aponta para a origem atual + rota do hóspede', qrVal === origin + ROUTE, qrVal)
  await shot(page, '09-qr-codes-desktop.png')
  await page.goto(qrVal)
  await page.waitForSelector('[data-testid="g-hello"]')
  check('QR → 204 → Olá, Mariana', (await body(page)).includes('Olá, Mariana'))
  await page.locator('[data-testid="g-cta"]').click()
  await page.locator('[data-opt="agua"]').click()
  await page.getByRole('button', { name: 'Aumentar' }).click()
  await page.locator('[data-testid="g-send"]').click()
  await page.waitForSelector('[data-testid="g-sent"]')
  check('Hóspede: pedido "2 garrafas de água" enviado (Pendente)', (await page.innerText('[data-testid="g-sent-title"]')) === '2 garrafas de água')

  // Gestão: Solicitação → Em andamento → Concluído
  await page.goto(BASE + '/solicitacoes'); await page.waitForSelector('.rq-grid')
  const card = page.locator('[data-request]', { hasText: '2 garrafas de água' })
  await card.getByRole('button', { name: 'Em andamento', exact: true }).click()
  check('Gestão: pedido → Em andamento', (await card.getAttribute('data-status')) === 'andamento')
  await card.getByRole('button', { name: 'Concluído', exact: true }).click()
  check('Gestão: pedido → Concluído', (await card.getAttribute('data-status')) === 'concluida')
  await shot(page, '05-solicitacoes-desktop.png')

  // Reserva → check-in
  await page.goto(BASE + '/reservas'); await page.waitForSelector('[data-res]')
  await page.locator('[data-res]', { hasText: 'Camila Souza' }).getByRole('button', { name: 'Fazer check-in' }).click()
  check('Reserva → Hospedado (check-in)', (await page.innerText('[data-testid="res-msg"]')) === 'Check-in feito no quarto 303.')
  await shot(page, '04-reservas-desktop.png')

  // Hospedado → check-out → limpeza
  await page.locator('[data-res]', { hasText: 'Fernanda Lima' }).getByRole('button', { name: 'Fazer check-out' }).click()
  check('Hospedado → check-out → limpeza (102)', (await page.innerText('[data-testid="res-msg"]')) === 'Check-out feito. Quarto 102 enviado para limpeza.')

  // Governança: Limpeza → Limpo → Livre
  await page.goto(BASE + '/governanca'); await page.waitForSelector('.lanes')
  const c = page.locator('[data-task][data-room="102"]')
  await c.getByRole('button', { name: 'Iniciar limpeza' }).click()
  await c.getByRole('button', { name: 'Marcar como limpo' }).click()
  await c.getByRole('button', { name: 'Liberar quarto' }).click()
  check('Governança: Limpeza → Limpo → Livre (102 liberado)', (await page.locator('[data-task][data-room="102"]').count()) === 0)
  await shot(page, '06-governanca-desktop.png')

  // Manutenção: origem da solicitação
  await page.goto(BASE + '/solicitacoes'); await page.waitForSelector('.rq-grid')
  await page.locator('[data-request]', { hasText: 'Ar-condicionado com ruído' }).getByRole('button', { name: 'Abrir ordem de manutenção' }).click()
  await page.goto(BASE + '/manutencao'); await page.waitForSelector('.lanes')
  const mt = page.locator('[data-task][data-room="208"]')
  const origin2 = await mt.locator('[data-testid="mt-origin"]').innerText()
  check('Manutenção: origem "Solicitação do hóspede" com hóspede e quarto', origin2.includes('Solicitação do hóspede') && origin2.includes('Bruno Carvalho') && origin2.includes('Quarto 208'), origin2.replace(/\n/g, ' | '))
  check('Manutenção: 207 mostra origem "Registrada pela equipe"', (await page.locator('[data-task][data-room="207"]').innerText()).includes('Registrada pela equipe'))
  await mt.getByRole('button', { name: 'Iniciar atendimento' }).click()
  await page.locator('[data-task][data-room="207"]').getByRole('button', { name: 'Iniciar atendimento' }).click()
  await page.locator('[data-task][data-room="207"]').getByRole('button', { name: 'Marcar como resolvido' }).click()
  check('Manutenção: Aberto → Em atendimento → Resolvido (207)', (await page.locator('[data-task][data-room="207"][data-status="concluida"]').count()) === 1)
  await shot(page, '07-manutencao-desktop.png')

  // Persistência (F5) e reset
  await page.goto(BASE + '/'); await page.reload(); await page.waitForSelector('.ops')
  check('Persistência F5: Dashboard mantém a operação', (await body(page)).includes('quarto 207: Resolvido'))
  await page.getByRole('button', { name: 'Restaurar demonstração' }).first().click()
  await page.goto(BASE + '/'); await page.waitForSelector('.ops')
  const d = await body(page)
  check('Reset: solicitações abertas volta a 7 e atividades iniciais', /Solicitações abertas\s*\n?\s*7/.test(d) && !d.includes('quarto 207: Resolvido'))
  check('Desktop: console sem erros', errors.length === 0, errors.join(' | '))
  await ctx.close()
}

// ---------- MOBILE ----------
{
  const { ctx, page, errors } = await session('Mobile 390', { viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, deviceScaleFactor: 2 })
  await page.goto(BASE + '/'); await page.evaluate(() => localStorage.clear()); await page.reload(); await page.waitForSelector('.ops')
  for (const r of ['/', '/quartos', '/reservas', '/solicitacoes', '/governanca', '/manutencao', '/qr-codes', ROUTE]) {
    await page.goto(BASE + r); await page.waitForTimeout(250)
    check(`Mobile sem rolagem horizontal em ${r}`, await noHScroll(page))
  }
  await page.goto(BASE + '/')
  await shot(page, '02-dashboard-mobile.png')
  await page.goto(BASE + ROUTE); await page.waitForSelector('[data-testid="g-hello"]')
  check('Mobile hóspede: sem menu de gestão', (await page.locator('.mob, nav.side').count()) === 0)
  await shot(page, '08-hospede-mobile.png', false)
  // alvo de toque mínimo no menu inferior e em botões
  await page.goto(BASE + '/solicitacoes'); await page.waitForSelector('.rq-grid')
  const minH = await page.evaluate(() => Math.min(...[...document.querySelectorAll('.seg button, .btn')].filter(e => e.offsetParent).map(e => e.getBoundingClientRect().height)))
  check('Mobile: botões de ação com altura mínima de toque (≥ 40px)', minH >= 40, `min=${minH}`)
  check('Mobile: console sem erros', errors.length === 0, errors.join(' | '))
  await ctx.close()
}

// ---------- telas extras para o pacote ----------
{
  const { ctx, page } = await session('Telas desktop', { viewport: { width: 1280, height: 900 } })
  await page.goto(BASE + '/quartos'); await page.waitForSelector('[data-room]'); await shot(page, '03-quartos-desktop.png')
  await ctx.close()
}

await browser.close()
console.log(`\n${total - fails}/${total} verificações OK`)
process.exit(fails ? 1 : 0)
