// Testes da camada de dados (Etapa 2). Rodar: npm test
import assert from 'node:assert/strict'
import { CATEGORIES, TENANT, createSeed } from '../src/data/seed'

// localStorage simulado (persistência real é testada recarregando o módulo da store)
const mem = new Map<string, string>()
;(globalThis as any).localStorage = {
  getItem: (k: string) => (mem.has(k) ? mem.get(k)! : null),
  setItem: (k: string, v: string) => void mem.set(k, v),
  removeItem: (k: string) => void mem.delete(k),
}

const store = await import('../src/data/store')
const sel = await import('../src/data/selectors')
let pass = 0
const t = (name: string, fn: () => void) => {
  fn()
  pass++
  console.log('  ✓', name)
}

const S = () => store.getState()
console.log('Seed')
t('28 quartos nas 4 categorias novas', () => {
  assert.equal(S().rooms.length, 28)
  assert.deepEqual(CATEGORIES.map(c => c.name), ['Suíte Standard', 'Suíte Deluxe', 'Suíte Família', 'Suíte Premium'])
  for (const old of ['Standard', 'Superior', 'Suíte Vista Mar', 'Chalé']) assert.ok(!CATEGORIES.some(c => c.name === old), old)
  assert.ok(S().rooms.every(r => CATEGORIES.some(c => c.id === r.category)))
})
t('tenant: Pousada Mar Azul, Guriri, administradora não é Mariana', () => {
  assert.equal(TENANT.name, 'Pousada Mar Azul')
  assert.equal(TENANT.loc, 'Guriri, São Mateus - ES')
  assert.ok(!TENANT.manager.includes('Mariana'))
})
t('quarto 204 OCUPADO por Mariana Costa (10/10 → 13/10) via reserva', () => {
  const room = sel.roomByNum(S(), '204')!
  assert.equal(room.status, 'o')
  const stay = sel.stayOf(S(), '204')!
  assert.equal(sel.guestName(S(), stay.guestId), 'Mariana Costa')
  assert.equal(stay.checkIn, '2026-10-10')
  assert.equal(stay.checkOut, '2026-10-13')
  assert.equal(stay.status, 'hospedado')
})
t('integridade: sem problemas', () => assert.deepEqual(sel.integrityProblems(S()), []))
t('KPIs derivados', () => {
  const k = sel.kpis(S())
  assert.equal(k.occupied, 21)
  assert.equal(k.total, 28)
  assert.equal(k.free, 4)
  assert.equal(k.cleaning, 2)
  assert.equal(k.maintenance, 1)
  assert.equal(k.occupied + k.free + k.cleaning + k.maintenance, 28)
  assert.equal(k.occupancyPct, 75) // 21/28 = 75%
  assert.equal(k.checkinsToday, 8)
  assert.equal(k.checkinsDone, 5)
  assert.equal(k.checkoutsToday, 5)
  assert.equal(k.checkoutsPending, 2)
  assert.equal(k.revenueMonth, 48920)
  assert.equal(k.openRequests, 7)
  assert.equal(k.urgentRequests, 2)
})
t('manutenção: mesmo quarto no mapa, nas tarefas e nos alertas', () => {
  const maint = S().rooms.filter(r => r.status === 'm').map(r => r.num)
  assert.deepEqual(maint, ['207'])
  assert.ok(S().tasks.some(x => x.room === '207' && x.kind === 'manutencao'))
  assert.ok(sel.alerts(S()).some(a => a.text.includes('Quarto 207 em manutenção há 2 dias')))
  assert.ok(!sel.alerts(S()).some(a => a.text.includes('214')))
})

console.log('Ações e consistência')
t('check-out do 204 libera quarto, cria limpeza e atualiza KPIs', () => {
  const stay = sel.stayOf(S(), '204')!
  assert.ok(store.checkOut(stay.id).ok)
  assert.equal(sel.roomByNum(S(), '204')!.status, 'l')
  const k = sel.kpis(S())
  assert.equal(k.occupied, 20)
  assert.equal(k.checkoutsToday, 6)
  assert.deepEqual(sel.integrityProblems(S()), [])
})
t('check-in numa chegada pendente ocupa o quarto', () => {
  const r = S().reservations.find(x => x.room === '103' && x.status === 'confirmada' && x.checkIn === '2026-10-10')!
  assert.ok(store.checkIn(r.id).ok)
  assert.equal(sel.roomByNum(S(), '103')!.status, 'o')
  assert.deepEqual(sel.integrityProblems(S()), [])
})
t('regras: não ocupa manualmente, não altera ocupado, check-in exige quarto livre', () => {
  assert.equal(store.setRoomStatus('106', 'o').ok, false)
  assert.equal(store.setRoomStatus('301', 'v').ok, false)
  const r = S().reservations.find(x => x.room === '303' && x.status === 'confirmada')!
  assert.ok(store.setRoomStatus('303', 'm').ok)
  assert.equal(store.checkIn(r.id).ok, false)
  assert.ok(store.setRoomStatus('303', 'v').ok)
  assert.deepEqual(sel.integrityProblems(S()), [])
})
t('solicitações: concluir reduz abertas; criar dedup', () => {
  const before = sel.kpis(S()).openRequests
  assert.ok(store.setRequestStatus('q3', 'concluida').ok)
  assert.equal(sel.kpis(S()).openRequests, before - 1)
  assert.ok(store.addRequest('301', 'toalhas', 'Toalhas extras').ok)
  const n = sel.kpis(S()).openRequests
  store.addRequest('301', 'toalhas', 'Toalhas extras')
  assert.equal(sel.kpis(S()).openRequests, n)
  assert.equal(store.addRequest('106', 'toalhas', 'x').ok, false)
})

console.log('Persistência e restauração')
t('alteração persiste após "recarregar"', () => {
  assert.ok(store.setRoomStatus('106', 'l').ok)
  assert.equal(JSON.parse(mem.get(store.STORAGE_KEY)!).rooms.find((r: any) => r.num === '106').status, 'l')
  store.reloadFromStorage() // simula F5
  assert.equal(sel.roomByNum(S(), '106')!.status, 'l')
  assert.equal(sel.roomByNum(S(), '204')!.status, 'l') // check-out anterior também persistiu
})
t('dados corrompidos/versão antiga → volta ao seed', () => {
  mem.set(store.STORAGE_KEY, '{lixo')
  store.reloadFromStorage()
  assert.equal(S().rooms.length, 28)
  mem.set(store.STORAGE_KEY, JSON.stringify({ version: 1, rooms: [] }))
  store.reloadFromStorage()
  assert.equal(sel.roomByNum(S(), '204')!.status, 'o')
})
t('restaurar demonstração volta ao estado inicial', () => {
  store.setRoomStatus('106', 'm')
  store.restoreDemo()
  assert.deepEqual(S(), createSeed())
  store.reloadFromStorage()
  assert.deepEqual(S(), createSeed())
  assert.equal(sel.roomByNum(S(), '204')!.status, 'o')
  assert.equal(sel.kpis(S()).openRequests, 7)
})

console.log('Etapa 3: pedido do hóspede, QR e rota')
t('hóspede cria "2 toalhas extras": Pendente, KPI +1, persiste, reset remove', () => {
  store.restoreDemo()
  const before = sel.kpis(S()).openRequests
  const r = store.submitGuestRequest('204', 'toalhas', 2)
  assert.ok(r.ok && r.id)
  const q = S().requests.find(x => x.id === r.id)!
  assert.equal(q.title, '2 toalhas extras')
  assert.equal(q.status, 'nova') // exibido como "Pendente"
  assert.equal(q.quantity, 2)
  assert.equal(q.origin, 'hospede')
  assert.equal(sel.kpis(S()).openRequests, before + 1)
  store.reloadFromStorage() // F5
  assert.ok(S().requests.some(x => x.id === r.id))
  store.restoreDemo()
  assert.ok(!S().requests.some(x => x.id === r.id))
  assert.equal(sel.kpis(S()).openRequests, before)
})
t('pedidos: títulos, validação e quarto sem hóspede', () => {
  store.restoreDemo()
  assert.equal(store.requestTitle('toalhas', 1), '1 toalha extra')
  assert.equal(store.requestTitle('agua', 3), '3 garrafas de água')
  assert.equal(store.requestTitle('travesseiros', 2), '2 travesseiros extras')
  assert.equal(store.submitGuestRequest('204', 'outro', 1, '   ').ok, false) // "outro" exige descrição
  assert.ok(store.submitGuestRequest('204', 'outro', 1, 'Um adaptador de tomada').ok)
  assert.equal(store.submitGuestRequest('106', 'limpeza').ok, false) // 106 não tem hóspede
  assert.equal(store.submitGuestRequest('999', 'limpeza').ok, false)
  const a = store.submitGuestRequest('204', 'toalhas', 2)
  const b = store.submitGuestRequest('204', 'toalhas', 2)
  assert.notEqual(a.id, b.id) // pedidos repetidos são pedidos novos
  store.restoreDemo()
})
t('rota e URL pública usam a origem atual (sem localhost fixo)', async () => {
  const { guestPath, guestUrl, parseGuestPath } = await import('../src/lib/urls')
  assert.equal(guestPath('204'), '/guest/mar-azul/room/204')
  assert.equal(guestPath('205'), '/guest/mar-azul/room/205')
  assert.deepEqual(parseGuestPath('/guest/mar-azul/room/204'), { slug: 'mar-azul', room: '204' })
  assert.equal(parseGuestPath('/quartos'), null)
  ;(globalThis as any).window = { location: { origin: 'https://nexor.vercel.app' } }
  assert.equal(guestUrl('204'), 'https://nexor.vercel.app/guest/mar-azul/room/204')
  delete (globalThis as any).window
})

console.log('Etapa 4: solicitações, governança, manutenção, check-in/out e atividades')
const task = (id: string) => S().tasks.find(x => x.id === id)!
t('seed: contadores da operação vêm da store (sem texto fixo)', () => {
  store.restoreDemo()
  const op = sel.operations(S())
  assert.deepEqual(op.requests, { pending: 5, inProgress: 2, done: 2, open: 7, urgent: 2 })
  assert.deepEqual(op.cleaning, { pending: 1, inProgress: 1, clean: 0, inspection: 0, open: 2 })
  assert.deepEqual(op.maintenance, { open: 1, inProgress: 0, resolved: 0, active: 1 })
  assert.deepEqual(op.checkins, { total: 8, done: 5 })
  assert.deepEqual(op.checkouts, { total: 5, done: 3 })
  assert.equal(sel.recentActivity(S(), 8).length, 8)
  assert.equal(sel.recentActivity(S(), 8)[0].text.includes('Check-in'), true) // mais recente primeiro
})
t('solicitação da Mariana (204): Pendente → Em andamento → Concluído → Pendente, com atividade', () => {
  assert.equal(sel.guestOfRoom(S(), '204'), 'Mariana Costa')
  const n = S().activity.length
  assert.equal(S().requests.find(q => q.id === 'q1')!.status, 'nova')
  assert.ok(store.setRequestStatus('q1', 'andamento').ok)
  assert.equal(sel.operations(S()).requests.inProgress, 3)
  assert.ok(store.setRequestStatus('q1', 'concluida').ok)
  assert.equal(sel.operations(S()).requests.open, 6)
  assert.ok(store.setRequestStatus('q1', 'nova').ok)
  assert.equal(sel.operations(S()).requests.open, 7)
  assert.equal(S().activity.length, n + 3)
  assert.equal(store.setRequestStatus('q1', 'nova').message, 'Sem alteração.')
  assert.equal(store.setRequestStatus('xx', 'concluida').ok, false)
})
t('pedido de hóspede novo entra nas atividades recentes', () => {
  const r = store.submitGuestRequest('204', 'toalhas', 2)
  assert.ok(r.ok)
  assert.ok(sel.recentActivity(S(), 1)[0].text.includes('2 toalhas extras'))
  store.restoreDemo()
})
t('check-out gera limpeza pendente (Governança) e atividade', () => {
  const res = S().reservations.find(r => r.room === '102' && r.status === 'hospedado')!
  assert.ok(store.checkOut(res.id).ok)
  assert.equal(sel.roomByNum(S(), '102')!.status, 'l')
  const tk = S().tasks.find(x => x.room === '102' && x.kind === 'limpeza' && x.status === 'pendente')!
  assert.ok(tk)
  assert.equal(sel.HK_LABEL[tk.status], 'Limpeza pendente')
  assert.deepEqual(sel.integrityProblems(S()), [])
  store.restoreDemo()
})
t('governança: Checkout → Limpeza → Limpo → Livre (inspeção opcional) e regras de transição', () => {
  // 108: limpeza pendente (seed) — não pode liberar nem ir para inspeção antes de Limpo
  assert.equal(store.setHousekeeping('t1', 'concluida').ok, false)
  assert.equal(store.setHousekeeping('t1', 'inspecao').ok, false)
  assert.ok(store.setHousekeeping('t1', 'andamento').ok)
  assert.equal(task('t1').status, 'andamento')
  assert.ok(store.setHousekeeping('t1', 'limpo').ok)
  assert.ok(store.setHousekeeping('t1', 'inspecao').ok)
  assert.equal(sel.roomByNum(S(), '108')!.status, 'l') // ainda não liberado
  assert.ok(store.setHousekeeping('t1', 'concluida').ok)
  assert.equal(sel.roomByNum(S(), '108')!.status, 'v') // Livre
  assert.equal(sel.housekeepingTasks(S()).some(x => x.id === 't1'), false)
  assert.equal(store.setHousekeeping('t1', 'andamento').ok, false) // já livre
  assert.deepEqual(sel.integrityProblems(S()), [])
})
t('governança: reprovação na inspeção volta para Em limpeza', () => {
  assert.ok(store.setHousekeeping('t2', 'limpo').ok)
  assert.ok(store.setHousekeeping('t2', 'inspecao').ok)
  assert.ok(store.setHousekeeping('t2', 'andamento').ok) // reprovado
  assert.equal(task('t2').status, 'andamento')
  assert.equal(sel.roomByNum(S(), '205')!.status, 'l')
  assert.ok(store.setHousekeeping('t2', 'limpo').ok)
  assert.ok(store.setHousekeeping('t2', 'concluida').ok) // liberar direto de Limpo
  assert.equal(sel.roomByNum(S(), '205')!.status, 'v')
  assert.deepEqual(sel.integrityProblems(S()), [])
})
t('manutenção: nova ordem marca quarto Livre como Manutenção; resolver devolve a Livre', () => {
  store.restoreDemo()
  assert.equal(store.openMaintenance('106', '').ok, false) // descrição obrigatória
  assert.equal(store.openMaintenance('999', 'Teste').ok, false)
  assert.ok(store.openMaintenance('106', 'Fechadura emperrada').ok)
  assert.equal(sel.roomByNum(S(), '106')!.status, 'm')
  const id = S().tasks.find(x => x.room === '106' && x.kind === 'manutencao')!.id
  assert.ok(store.setMaintenance(id, 'andamento').ok)
  assert.equal(sel.roomByNum(S(), '106')!.status, 'm')
  assert.ok(store.setMaintenance(id, 'concluida').ok)
  assert.equal(sel.roomByNum(S(), '106')!.status, 'v')
  assert.ok(store.setMaintenance(id, 'pendente').ok) // reabrir
  assert.equal(sel.roomByNum(S(), '106')!.status, 'm')
  assert.deepEqual(sel.integrityProblems(S()), [])
})
t('manutenção: quarto 207 (Ar-condicionado) aparece Aberto e resolve para Livre', () => {
  store.restoreDemo()
  const ops = sel.operations(S())
  assert.equal(ops.maintenance.open, 1)
  assert.equal(S().tasks.find(x => x.id === 't3')!.title, 'Ar-condicionado')
  assert.ok(store.setMaintenance('t3', 'andamento').ok)
  assert.equal(sel.operations(S()).maintenance.inProgress, 1)
  assert.ok(store.setMaintenance('t3', 'concluida').ok)
  assert.equal(sel.roomByNum(S(), '207')!.status, 'v')
  assert.equal(sel.operations(S()).maintenance.resolved, 1)
  assert.equal(sel.operations(S()).maintenance.active, 0)
  assert.deepEqual(sel.integrityProblems(S()), [])
})
t('manutenção a partir de solicitação do hóspede (chuveiro, 105)', () => {
  store.restoreDemo()
  assert.ok(store.requestToMaintenance('q3').ok)
  assert.equal(S().requests.find(q => q.id === 'q3')!.status, 'andamento')
  assert.ok(S().tasks.some(x => x.room === '105' && x.kind === 'manutencao' && x.title === 'Chuveiro sem água quente'))
  assert.equal(sel.roomByNum(S(), '105')!.status, 'o') // hóspede segue no quarto
  assert.deepEqual(sel.integrityProblems(S()), [])
})
t('check-in gera atividade e atualiza o contador de check-ins', () => {
  store.restoreDemo()
  const before = sel.operations(S()).checkins.done
  const r = S().reservations.find(x => x.room === '303' && x.status === 'confirmada')!
  assert.ok(store.checkIn(r.id).ok)
  assert.equal(sel.operations(S()).checkins.done, before + 1)
  assert.equal(sel.recentActivity(S(), 1)[0].text, 'Check-in · Camila Souza · quarto 303 ocupado')
  assert.ok(S().activity.some(a => a.text.includes('quarto 303 ocupado')))
  assert.deepEqual(sel.integrityProblems(S()), [])
})
t('origem da manutenção: solicitação do hóspede mostra hóspede e origem', () => {
  store.restoreDemo()
  assert.ok(store.requestToMaintenance('q5').ok)
  const tk = S().tasks.find(x => x.room === '208' && x.kind === 'manutencao')!
  assert.equal(tk.origin, 'Solicitação do hóspede')
  assert.equal(tk.guest, 'Bruno Carvalho')
  assert.equal(S().tasks.find(x => x.id === 't3')!.origin, undefined) // seed: registrada pela equipe
  store.restoreDemo()
})
t('hóspede do quarto: quem saiu (não reservas futuras)', () => {
  store.restoreDemo()
  assert.equal(sel.guestOfRoom(S(), '108'), 'Patrícia Gomes') // 108 tem pré-reserva futura (Gabriela), não é ela
  assert.equal(sel.guestOfRoom(S(), '204'), 'Mariana Costa') // hospedada agora
  assert.equal(sel.guestOfRoom(S(), '106'), 'Felipe Araújo') // check-out de hoje
  assert.equal(sel.guestOfRoom(S(), '101'), 'Rafael Almeida')
  assert.equal(sel.guestOfRoom(S(), '999'), '—')
})
t('integridade: quarto em limpeza sem tarefa é detectado', () => {
  store.restoreDemo()
  const bad = JSON.parse(JSON.stringify(S()))
  bad.rooms.find((r: any) => r.num === '106').status = 'l' // sem tarefa de limpeza
  mem.set(store.STORAGE_KEY, JSON.stringify(bad))
  store.reloadFromStorage()
  assert.ok(sel.integrityProblems(S()).some(p => p.includes('106') && p.includes('limpeza')))
  store.restoreDemo()
})
t('migração: dados da Etapa 3 (sem atividades) carregam sem perder pedidos', () => {
  const old = JSON.parse(JSON.stringify(createSeed())) as any
  delete old.activity
  old.requests.push({ id: 'qhosp', room: '204', kind: 'agua', title: 'Água gelada extra', status: 'nova', urgent: false })
  mem.set(store.STORAGE_KEY, JSON.stringify(old))
  store.reloadFromStorage()
  assert.deepEqual(S().activity, [])
  assert.ok(S().requests.some(q => q.id === 'qhosp'))
  assert.equal(sel.roomByNum(S(), '204')!.status, 'o')
  store.restoreDemo()
})
t('persistência e reset das etapas 4: tudo volta ao seed', () => {
  store.restoreDemo()
  store.setHousekeeping('t1', 'andamento')
  store.setMaintenance('t3', 'andamento')
  store.setRequestStatus('q2', 'concluida')
  store.reloadFromStorage() // F5
  assert.equal(task('t1').status, 'andamento')
  assert.equal(task('t3').status, 'andamento')
  store.restoreDemo()
  assert.deepEqual(S(), createSeed())
  store.reloadFromStorage()
  assert.deepEqual(S(), createSeed())
})

console.log(`\n${pass} testes OK`)
