// Teste da Etapa 4 no navegador (sandbox, Playwright global). Uso: node scripts/sandbox-e2e-etapa4.mjs [pasta-de-screenshots]
import { createRequire } from 'node:module'
import fs from 'node:fs'
const G = process.env.NPM_GLOBAL || '/home/claude/.npm-global/lib/node_modules'
const { chromium } = createRequire(G + '/')('playwright')
const OUT = process.argv[2] || './screenshots'
fs.mkdirSync(OUT, { recursive: true })
const BASE = 'http://localhost:4173'
const ROUTE = '/guest/mar-azul/room/204'
const browser = await chromium.launch({ executablePath: process.env.CHROME || '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--no-sandbox'] })
let fails = 0, total = 0
const check = (name, cond, extra = '') => { total++; if (!cond) fails++; console.log(cond ? '  ✓' : '  ✗ FALHOU:', name, extra) }
const body = page => page.innerText('body')
const shot = async (page, file, full = true) => { await page.waitForTimeout(600); await page.screenshot({ path: `${OUT}/${file}`, fullPage: full }) }
const noHScroll = page => page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)

async function session(label, opts) {
  const ctx = await browser.newContext({ ...opts, colorScheme: 'dark' })
  const page = await ctx.newPage()
  const errors = []
  page.on('console', m => m.type() === 'error' && errors.push(m.text()))
  page.on('pageerror', e => errors.push(String(e)))
  console.log(`\n== ${label} ==`)
  await page.goto(BASE + '/'); await page.evaluate(() => localStorage.clear()); await page.reload()
  await page.waitForSelector('.ops')
  return { ctx, page, errors }
}

// ---------------- DESKTOP ----------------
{
  const { ctx, page, errors } = await session('Desktop 1280', { viewport: { width: 1280, height: 900 } })

  // Dashboard: números vindos da store
  const t0 = await body(page)
  check('Dashboard: tiles operacionais (Solicitações, Limpeza, Manutenção, Check-ins, Check-outs)', ['Solicitações', 'Limpeza', 'Manutenção', 'Check-ins', 'Check-outs'].every(x => t0.includes(x)))
  check('Dashboard: Solicitações abertas = 7 (store)', /Solicitações abertas\s*\n?\s*7/.test(t0))
  check('Dashboard: atividades recentes listadas', (await page.locator('[data-activity]').count()) === 8)
  await shot(page, '01-dashboard-desktop.png')

  // Solicitações → alteração de status → Dashboard → hóspede
  await page.locator('nav.side a', { hasText: 'Solicitações' }).click()
  await page.waitForSelector('.rq-grid')
  check('Solicitações: 9 cards (todas)', (await page.locator('[data-request]').count()) === 9)
  await page.getByRole('tab', { name: /Pendentes/ }).click()
  check('Solicitações: filtro Pendentes mostra só pendentes', (await page.locator('[data-request][data-status="nova"]').count()) === (await page.locator('[data-request]').count()) && (await page.locator('[data-request]').count()) === 5)
  await page.getByRole('tab', { name: /Todas/ }).click()
  const card = page.locator('[data-request]', { hasText: 'Água gelada' })
  check('Solicitações: pedido da Mariana (quarto 204) aparece com nome do hóspede', (await card.innerText()).includes('Mariana Costa') && (await card.innerText()).includes('Quarto 204'))
  await card.getByRole('button', { name: 'Em andamento', exact: true }).click()
  check('Solicitações: status alterado para Em andamento', (await card.locator('[data-testid="rq-status"]').innerText()) === 'Em andamento')
  await shot(page, '02-solicitacoes-desktop.png')
  await page.goto(BASE + '/')
  check('Dashboard reflete: "Água gelada" virou Em andamento', (await page.locator('.row', { hasText: 'Água gelada' }).innerText()).includes('Em andamento'))
  await page.goto(BASE + ROUTE)
  await page.waitForSelector('[data-testid="g-requests"]')
  check('Hóspede (204) vê o pedido "Em andamento"', (await page.locator('[data-request="q1"]').innerText()).includes('Em andamento'))
  await page.goto(BASE + '/solicitacoes'); await page.waitForSelector('.rq-grid')
  await page.locator('[data-request]', { hasText: 'Água gelada' }).getByRole('button', { name: 'Concluído', exact: true }).click()
  await page.goto(BASE + ROUTE); await page.waitForSelector('[data-testid="g-requests"]')
  check('Hóspede (204) vê o pedido "Concluído" após a gestão concluir', (await page.locator('[data-request="q1"]').innerText()).includes('Concluído'))
  // de volta a Pendente para deixar o cenário original consistente
  await page.goto(BASE + '/solicitacoes'); await page.waitForSelector('.rq-grid')
  await page.locator('[data-request]', { hasText: 'Água gelada' }).getByRole('button', { name: 'Pendente', exact: true }).click()
  // Manutenção a partir de solicitação do hóspede (208 — ar-condicionado com ruído)
  await page.locator('[data-request]', { hasText: 'Ar-condicionado com ruído' }).getByRole('button', { name: 'Abrir ordem de manutenção' }).click()
  check('Solicitação de manutenção vira ordem (toast)', (await body(page)).includes('Ordem de manutenção criada'))

  // Check-in (Reservas)
  await page.locator('nav.side a', { hasText: 'Reservas' }).click()
  await page.waitForSelector('[data-res]')
  const camila = page.locator('[data-res]', { hasText: 'Camila Souza' })
  await camila.getByRole('button', { name: 'Fazer check-in' }).click()
  check('Check-in: toast confirma quarto 303', (await page.innerText('[data-testid="res-msg"]')) === 'Check-in feito no quarto 303.')
  check('Check-in: reserva vira Hospedado', (await camila.innerText()).includes('Hospedado'))
  await page.goto(BASE + '/quartos')
  check('Check-in: quarto 303 aparece Ocupado no mapa', (await page.locator('[data-room="303"]').innerText()).includes('Ocupado'))
  await page.goto(BASE + '/reservas'); await page.waitForSelector('[data-res]')
  await shot(page, '03-checkin-reserva-desktop.png')

  // Check-out (Reservas): Fernanda Lima, quarto 102
  const fernanda = page.locator('[data-res]', { hasText: 'Fernanda Lima' })
  await fernanda.getByRole('button', { name: 'Fazer check-out' }).click()
  check('Check-out: toast e quarto 102 enviado para limpeza', (await page.innerText('[data-testid="res-msg"]')) === 'Check-out feito. Quarto 102 enviado para limpeza.')
  await shot(page, '04-checkout-desktop.png')

  // Governança
  await page.locator('nav.side a', { hasText: 'Governança' }).click()
  await page.waitForSelector('.lanes')
  const lanes = await page.locator('.lane').allInnerTexts()
  check('Governança: 4 etapas (Limpeza pendente, Em limpeza, Limpo, Inspeção)', lanes.length === 4 && /Limpeza pendente/.test(lanes[0]) && /Inspeção/.test(lanes[3]))
  check('Governança: quarto 102 (check-out da Fernanda) em Limpeza pendente', (await page.locator('.lane').nth(0).innerText()).includes('Quarto 102'))
  await page.waitForTimeout(400)
  await shot(page, '05-governanca-desktop.png')
  const c102 = page.locator('[data-task][data-room="102"]')
  await c102.getByRole('button', { name: 'Iniciar limpeza' }).click()
  check('Governança: 102 → Em limpeza', (await c102.getAttribute('data-status')) === 'andamento')
  await c102.getByRole('button', { name: 'Marcar como limpo' }).click()
  check('Governança: 102 → Limpo', (await c102.getAttribute('data-status')) === 'limpo')
  await c102.getByRole('button', { name: 'Liberar quarto' }).click()
  check('Governança: 102 sai das etapas (liberado)', (await page.locator('[data-task][data-room="102"]').count()) === 0)
  await page.goto(BASE + '/quartos')
  check('Quartos: 102 agora Livre (Limpo → Livre)', (await page.locator('[data-room="102"]').innerText()).includes('Livre'))

  // Manutenção
  await page.locator('nav.side a', { hasText: 'Manutenção' }).click()
  await page.waitForSelector('.lanes')
  const c207 = page.locator('[data-task][data-room="207"]')
  check('Manutenção: Quarto 207 — Ar-condicionado em Aberto', (await c207.innerText()).includes('Ar-condicionado') && (await c207.innerText()).includes('Quarto 207') && (await page.locator('.lane').nth(0).innerText()).includes('207'))
  await c207.getByRole('button', { name: 'Iniciar atendimento' }).click()
  check('Manutenção: 207 → Em atendimento', (await c207.getAttribute('data-status')) === 'andamento')
  await page.getByRole('button', { name: 'Nova ordem' }).click()
  await page.getByTestId('mt-room').selectOption('106')
  await page.getByTestId('mt-title').fill('Fechadura emperrada')
  await page.getByTestId('mt-submit').click()
  check('Manutenção: nova ordem aberta (toast + card)', (await page.innerText('[data-testid="mt-msg"]')) === 'Ordem de manutenção aberta.' && (await page.locator('[data-task][data-room="106"]').count()) === 1)
  await c207.getByRole('button', { name: 'Marcar como resolvido' }).click()
  check('Manutenção: 207 Resolvido', (await c207.getAttribute('data-status')) === 'concluida')
  await page.waitForTimeout(400)
  await shot(page, '06-manutencao-desktop.png')

  // Persistência e reset
  await page.goto(BASE + '/')
  const d = await body(page)
  check('Persistência: atividades seguem após recarregar (Resolvido do 207 registrado)', (await page.locator('[data-activity]').count()) === 8 && d.includes('quarto 207: Resolvido'))
  await page.goto(BASE + '/manutencao'); await page.waitForSelector('.lanes')
  check('Persistência: 207 segue Resolvido após F5', (await page.locator('[data-task][data-room="207"][data-status="concluida"]').count()) === 1)
  await page.getByRole('button', { name: 'Restaurar demonstração' }).first().click()
  await page.goto(BASE + '/'); await page.waitForSelector('.ops')
  const r = await body(page)
  check('Reset: Solicitações abertas volta a 7', /Solicitações abertas\s*\n?\s*7/.test(r))
  check('Reset: Dashboard volta às atividades iniciais (sem "Fechadura emperrada")', !r.includes('Fechadura emperrada'))
  await page.goto(BASE + '/governanca')
  check('Reset: Governança volta ao seed (108 e 205 em limpeza; 102 fora, pois a Fernanda voltou a estar hospedada)', (await page.locator('[data-task][data-room="102"]').count()) === 0 && (await page.locator('[data-task][data-room="108"]').count()) === 1 && (await page.locator('[data-task][data-room="205"]').count()) === 1)
  check('Desktop: sem rolagem horizontal', await noHScroll(page))
  check('Desktop: console sem erros', errors.length === 0, errors.join(' | '))
  await ctx.close()
}

// ---------------- MOBILE ----------------
{
  const { ctx, page, errors } = await session('Mobile 390', { viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, deviceScaleFactor: 2 })
  await page.goto(BASE + '/')
  check('Mobile: menu inferior com as 8 telas de gestão', (await page.locator('.mob a').count()) === 8)
  await shot(page, '07-dashboard-mobile.png')
  check('Mobile dashboard: sem rolagem horizontal', await noHScroll(page))
  await page.goto(BASE + '/solicitacoes'); await page.waitForSelector('.rq-grid')
  await shot(page, '08-operacao-mobile-solicitacoes.png', false)
  check('Mobile solicitações: sem rolagem horizontal', await noHScroll(page))
  await page.goto(BASE + '/governanca'); await page.waitForSelector('.lanes')
  check('Mobile governança: etapas empilhadas e sem rolagem horizontal', await noHScroll(page))
  await shot(page, '09-operacao-mobile-governanca.png', false)
  await page.goto(BASE + ROUTE); await page.waitForSelector('[data-testid="g-hello"]')
  check('Mobile hóspede: Olá, Mariana e quarto 204 continuam', (await body(page)).includes('Olá, Mariana') && (await body(page)).includes('Quarto 204'))
  check('Mobile hóspede: sem menu de gestão', (await page.locator('.mob, nav.side').count()) === 0)
  await shot(page, '10-hospede-mobile.png', false)
  check('Mobile: console sem erros', errors.length === 0, errors.join(' | '))
  await ctx.close()
}

// Rota pública e QR (regressão rápida)
{
  const { ctx, page, errors } = await session('Regressão: rota e QR', { viewport: { width: 1280, height: 900 } })
  await page.goto(BASE + '/qr-codes'); await page.waitForSelector('[data-qr-room]')
  check('QR: 28 QRs continuam', (await page.locator('[data-qr-room]').count()) === 28)
  await page.goto(BASE + ROUTE); await page.waitForSelector('[data-testid="g-hello"]')
  check('Rota /guest/mar-azul/room/204 abre Mariana Costa', (await body(page)).includes('Olá, Mariana') && (await body(page)).includes('Mariana Costa'))
  check('Rota do hóspede sem menu de gestão', (await page.locator('nav.side').count()) === 0)
  check('Regressão: console sem erros', errors.length === 0, errors.join(' | '))
  await ctx.close()
}

await browser.close()
console.log(`\n${total - fails}/${total} verificações OK`)
process.exit(fails ? 1 : 0)
