// Build equivalente usado SÓ no sandbox sem internet (Vite não instalável). No seu computador use: npm run dev / build.
import { createRequire } from 'node:module'
import fs from 'node:fs'
import path from 'node:path'
const G = process.env.NPM_GLOBAL || '/home/claude/.npm-global/lib/node_modules'
const require = createRequire(G + '/')
const esbuild = require(G + '/tsx/node_modules/esbuild')
const root = path.resolve(import.meta.dirname, '..')
const dist = path.join(root, 'dist')
fs.rmSync(dist, { recursive: true, force: true })
fs.mkdirSync(path.join(dist, 'assets'), { recursive: true })
await esbuild.build({
  entryPoints: [path.join(root, 'src/main.tsx')],
  bundle: true, outdir: path.join(dist, 'assets'), jsx: 'automatic', minify: true, format: 'esm',
  define: { 'process.env.NODE_ENV': '"production"' },
  nodePaths: [G], sourcemap: false,
})
fs.cpSync(path.join(root, 'public'), dist, { recursive: true })
let html = fs.readFileSync(path.join(root, 'index.html'), 'utf8')
html = html.replace('<script type="module" src="/src/main.tsx"></script>', '<link rel="stylesheet" href="/assets/main.css" /><script type="module" src="/assets/main.js"></script>')
fs.writeFileSync(path.join(dist, 'index.html'), html)
console.log('build ok')
