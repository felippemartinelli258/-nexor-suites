// Service worker do Nexor Suítes: cache mínimo para abertura offline do demo.
// Estratégia: navegação → rede, com fallback para o shell (index.html) em cache;
// assets do mesmo domínio → cache imediato + atualização em segundo plano.
// A store continua no localStorage (não depende de rede).
const CACHE = 'nexor-suites-v5'
const CORE = [
  '/',
  '/index.html',
  '/manifest.webmanifest',
  '/favicon.png',
  '/brand/nexor-icon-180.png',
  '/brand/nexor-icon-192.png',
  '/brand/nexor-icon-512.png',
  '/brand/nexor-icon-maskable-512.png',
]

self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(c => c.addAll(CORE)).then(() => self.skipWaiting()))
})

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim()),
  )
})

self.addEventListener('fetch', event => {
  const req = event.request
  if (req.method !== 'GET') return
  const url = new URL(req.url)
  if (url.origin !== self.location.origin) return

  if (req.mode === 'navigate') {
    event.respondWith(
      fetch(req)
        .then(res => {
          if (res.ok) {
            const copy = res.clone()
            caches.open(CACHE).then(c => c.put('/index.html', copy))
          }
          return res
        })
        .catch(() => caches.match('/index.html', { ignoreSearch: true }).then(hit => hit || Response.error())),
    )
    return
  }

  event.respondWith(
    caches.match(req).then(hit => {
      const network = fetch(req)
        .then(res => {
          if (res.ok) {
            const copy = res.clone()
            caches.open(CACHE).then(c => c.put(req, copy))
          }
          return res
        })
        .catch(() => hit || Response.error())
      return hit || network
    }),
  )
})
